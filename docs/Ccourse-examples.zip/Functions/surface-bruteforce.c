/*
surface-bruteforce.c
calculate the surface of a triangle
*/
#include<stdio.h>

int main(void){

double surftri = 0;  // surface of trangle
double height = 0;   // height
double base = 0;     // base

/* triangle 1 */

base = 10.8;
height = 6.7;
surftri = (base * height) / 2.0;

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", height, base, surftri);

/* triangle 2 */

base = 4.8;
height = 2.0;
surftri = (base * height) / 2.0;

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", height, base, surftri);

/* triangle 3 */

base = 188.8;
height = 65.7;
surftri = (base * height) / 2.0;

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", height, base, surftri);

return 0;
}
