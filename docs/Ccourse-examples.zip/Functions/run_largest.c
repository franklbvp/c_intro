#include <stdio.h>

int get_largest(int x, int y, int z);


int main(){
int val1, val2, val3;
int lval;

val1 = -7;
val2 = -13;
val3 = 8;

lval = get_largest(val1, val2, val3);
printf("largest value = %d \n", lval);

return 0;
}



int get_largest(int x, int y, int z) {
    
   if (x > y) {
      if (x > z) {
         return x;}
      else {
         return z;}
      }
   else {
      if (y > z) {
         return y;}
      else {
         return z;}
      }
}
