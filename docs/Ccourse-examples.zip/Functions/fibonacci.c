/*
fibonacci.c
calculate the nth fibonacci number
 fibonacci - recursive
 Fibonacci(n) = Fibonacci(n-1) + Fibonacci(n-2)
where:
Fibonacci(0) = 0
Fibonacci(1) = 1

based on http://gribblelab.org/cbootcamp/5_Functions.html

*/


#include <stdio.h>

int Fibonacci(int n);

int main() {
        int n = 11;

        int Fn = Fibonacci(n);

        printf (" enter an integer (larger than 2, but not too large):");
        scanf("%d", &n);
        printf (" %d th fibonacci number = %d \n",n, Fibonacci(n));

    return 0;
}


int Fibonacci(int n) {
        if (n==0) return 0;
        else if (n==1) return 1;
        else return Fibonacci(n-1) + Fibonacci(n-2);
}
