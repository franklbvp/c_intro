/* demo_swap_by_val.c */
#include <stdio.h>

void swap(int i, int j);

void main()
{
    int a,b;
    a=5;
    b=10;
    printf("a=%d, b=%d  -before swap-\n",a,b);
    swap(a,b);
    printf("a=%d, b=%d  -after swap-\n",a,b);
}
void swap(int i, int j)
{
    int t;
    t = i;
    i = j;
    j = t;
}
