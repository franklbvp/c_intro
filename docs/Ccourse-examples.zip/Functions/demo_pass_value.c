#include <stdio.h>

void subfunc (int a);
void func (void);

int main (void)
{
  func ();
  return 0;
}


void subfunc (int a)
{
  a = 3;
  printf ("in subfunc, a = %d \n", a);
}

void func (void)
{
  int a, b;

  a = 0;
  subfunc (a);
  b = a;
  printf ("in func, b = %d, a = %d \n", b, a);
}
