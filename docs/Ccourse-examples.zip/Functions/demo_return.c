#include<stdio.h>

/* test return value */

int main (void)

{

printf(" return value 5, check this with echo $? \n");

return 5;

}
