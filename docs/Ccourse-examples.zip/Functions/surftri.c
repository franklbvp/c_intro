/* function definition
calculate surface of a triangle
 */
double surftri(double base, double height)
{ double result;
result = (base * height) / 2.0;
return (result);
} 
