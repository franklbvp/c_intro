
#include <stdio.h>

int show(int x);


int main(){
int val1, val2;


val1 = 1;
val2 = 13;

show(val1);
show(val2);


return 0;
}


int show(int x) {
    printf("%d %d\n", x, x*x);
    return x*x;

    printf("%d %d\n", x, x*x*x);
    return x*x*x;
}
