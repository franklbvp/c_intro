//print_square.h
void print_square(int);

