/*
surface-function.c
calculate the surface of a triangle
*/
#include<stdio.h>

double surftri(double base, double height);  // function declaration

int main(){

double height = 0;   // height
double base = 0;     // base
double surf1 = 0, surf2 = 0;

/* triangle 1 */

base = 10.8;
height = 6.7;
surf1 = surftri(base, height); 

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", height, base, surf1);

/* triangle 2 */

base = 4.8;
height = 2.0;
surf2 = surftri(4.8, 2.0);

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", 4.8, 2.0, surf2);

/* triangle 3 */

printf(" triangle - height %7.3f - base %7.3f = surface %7.3f \n", 65.7, 188.8, surftri(188.8, 65.7));

return 0;
}

/* function definition
include the print statement or not */
double surftri(double base, double height)
{ double result;
result = (base * height) / 2.0;
return (result);
} 
