double surftri(double base, double height); 
