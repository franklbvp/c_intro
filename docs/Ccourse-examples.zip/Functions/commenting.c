/* Compute array of all primes less than n.
 *
 * Arguments:
 *  array - an array of integers, caller must ensure it is initially all zeros
 *  n - number of elements in the array
 *
 * Remarks: The array elements mark whether each element is prime or composite 
 *  as follows,
 *        array[i] == 0 means i is prime, and 
 *        array[i] == 1 means i is composite.
 * 
 * Reference: This function uses an algorithm known as the Sieve of 
 *  Eratosthenes, adapted from CRC Handbook of Discrete and Combinatorial 
 *  Mathematics, page 246. */
void compute_primes(int *array, int n) 
{
    int i, sqrtn = sqrt(n);

    array[0] = array[1] = 1; /* 0 and 1 are not prime, by definition */

    /* All multiples are composite, mark them off */
    for (i = 2; i <= sqrtn; ++i)
        if (array[i] == 0) {
            int j, k;
            for (j = i; (k = i*j) < n; ++j)
                array[k] = 1;
        }
}
