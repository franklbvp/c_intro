/*

demo_return_multi_values_1


this is a demo showing the use of an array to reurn multiple values from a function

source: www.gidforums.com/t-20163.html
*/
#include <stdio.h>

int get_floats(float x[], int n);

int main()
{
    int i, n;
    float x[4];

    n = get_floats(x, 4);
    for (i = 0; i < n; i++) {
        printf("x[%d] = %f\n", i, x[i]);
    }
    return 0;
}
/* return the number of successful conversions */
int get_floats(float x[], int n)
{
    int i;
    for (i = 0; i < n; i++) {
        printf("Enter float number %d ", i);
        if (scanf("%f", &x[i]) != 1) {
            printf("Invalid input trying to read x[%d]\n", i);
            break; /* or whatever you want to do in case of error */
        }
    }
    return i;
}


