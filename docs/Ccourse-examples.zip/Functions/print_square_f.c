#include <stdio.h>
// print_square_f.c 
void print_square(int value) {
   printf("%d squared = %d\n", value, value * value);
   return;
}

