/*
print_square_modular.c
print the square of an integer

use a modular approach

gcc -g -o print_square print_square_modular.c  print_square_f.c
*/

#include<stdio.h>
#include"sub/print_square.h"
 
 
int main(void) {
   int number=0;


   number = 5;
   print_square(number);

   number = 8;
   print_square(number);

   number = 51;
   print_square(number);

   number = 85;
   print_square(85);

return 0;
}

