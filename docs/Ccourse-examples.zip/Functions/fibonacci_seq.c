/*
 fibonacci - sequential
 Fibonacci(n) = Fibonacci(n-1) + Fibonacci(n-2)
where:
Fibonacci(0) = 0
Fibonacci(1) = 1

*/

#include <stdio.h>

int   old_number;     /* previous Fibonacci number */
int   current_number; /* current Fibonacci number */
int   next_number;    /* next number in the series */
int   x, icount;

int main()
{
    printf (" enter an integer (larger than 2):");
    scanf("%d", &x); 
 
 /* start things out */
    old_number = 0;
    current_number = 1;
    icount = 2;


    while (icount <= x) {

        next_number = current_number + old_number;
        icount = icount + 1;
        old_number = current_number;
        current_number = next_number;
    }
	printf (" %d th fibonacci number = %d \n",x, next_number);
    return 0;
}
