/* Source: tim bailey � demo_function_deffirst.c

*/

#include <stdio.h>
#include <math.h> /* log() and sqrt() */

/* Compute the inverse hyperbolic sine of an angle x, where x is in radians. */
double asinh(double x)
{
    return log(x + sqrt(x * x + 1.0));
}

int main(void)
{
    double a = 0.3;
    printf("asinh(%f) = %f\n", a, asinh(a));
    return 0;
}
