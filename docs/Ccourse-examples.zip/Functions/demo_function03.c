/*--------------------------------------------------------------------------
This program demonstrates the use of functions
--------------------------------------------------------------------------*/

#include <stdio.h>

/* Function prototype statements */
void   moe( void );
void   curly( int count );
void   larry( int Tom, int Dick, int Harry );
int    joe( int x, int y, int z );

int main()
{
   int a = 10;
   int b = 20;
   int c = 30;
   int result;

   printf( "Starting program...\n\n" );
   moe();
   printf( "Back from moe...\n\n" );

   curly( 5 );

   printf( "Before larry: a=%d, b=%d, c=%d\n\n", a, b, c );
   larry( a, b, c );
   printf( "After larry:  a=%d, b=%d, c=%d\n\n", a, b, c );

   joe( a, b, c );

   return( 0 );
}

/* Here's the first function - all it does is print one message */

void moe( )
{
   printf( "Now in function moe.\n\n" );
}

/* Here's the 2nd function - it just does some looping */

void curly( int count )
{
   printf( "In function curly: " );
   while ( count > 0 )
   {
      printf( " %d", count );
      count--;
   }
   printf( "\n\n" );
}

/* This function changes its arguments, but are they really changed? */

void larry( int x, int y, int z )
{
   printf( "In function larry: x=%d, y=%d, z=%d\n\n", x, y, z );
   x = 40;
   y = 50;
   z = 60;
   printf( "In function larry: x=%d, y=%d, z=%d\n\n", x, y, z );

   moe();  /* nested function call */
}

/* This function does some calculations and returns a value */

int joe( int a, int b, int c )
{
   int result;

   printf( "In function joe: result=%d\n\n", result );
   result = a + b + c;
   printf( "In function joe: result=%d\n\n", result );

   return( result );
}