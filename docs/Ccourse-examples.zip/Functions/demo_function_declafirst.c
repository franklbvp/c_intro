/* Source: tim bailey � demo_function_declafirst.c

*/
#include <stdio.h>
#include <math.h> /* log() and sqrt() */

double asinh(double x); /* Function prototype */

int main(void)
{
    double a = 0.3;
    printf("asinh(%f) = %f\n", a, asinh(a));
    return 0;
}

/* Function definition */
double asinh(double x)
{
    return log(x + sqrt(x * x + 1.0));
}
