/*--------------------------------------------------------------------------
This program demonstrates the scope and lifespan of variables
--------------------------------------------------------------------------*/
#include <stdio.h>

/* Function prototype statements */
int function1( int parm );
int function2( int );
int function3( int Hello );

/* Global varaibles here */
int gbl = 10;

int main( void )
{
   /* Variables local to main here */
   int lcl = 20, i = 555;

   printf( "(main-1) gbl=%d, lcl=%d\n\n", gbl, lcl );
   {
      int blk; /* 'blk' known only in this block */
      int lcl; /* a more local 'lcl'! */
      blk = 2001;
      lcl += blk;
      printf( "(block-1) gbl=%d lcl=%d blk=%d i=%d\n\n", gbl, lcl, blk, i );
   }
   printf( "(main-2) gbl=%d, lcl=%d\n", gbl, lcl );

   function1( lcl );
   printf( "(main-3), gbl=%d, lcl=%d\n\n", gbl, lcl );

   function2( lcl );
   printf( "(main-4), gbl=%d, lcl=%d\n\n", gbl, lcl );

   gbl = function3( 200 );
   printf( "(main-5), gbl=%d, lcl=%d\n\n", gbl, lcl );
   lcl = function3( 1001 );
   printf( "(main-6), gbl=%d, lcl=%d\n\n", gbl, lcl );

   return( 0 );
}

/* This guy modifies his own 'lcl' and everyone's 'gbl' */
int function1( int parm )
{
   int lcl = 400;

   printf( "(function1-1) gbl=%d, lcl=%d, parm=%d\n\n", gbl, lcl, parm );
   gbl = parm;
   printf( "(function1-2) gbl=%d, lcl=%d, parm=%d\n\n", gbl, lcl, parm );

   return( gbl );
}

/* This guy modifies his own gbl and lcl */
int function2( int parm )
{
   int lcl = 400;
   int gbl = 1024;

   printf( "(function2-1) gbl=%d, lcl=%d, parm=%d\n\n", gbl, lcl, parm );
   gbl = parm * 2;
   printf( "(function2-2) gbl=%d, lcl=%d, parm=%d\n\n", gbl, lcl, parm );

   return( gbl );
}

/* This guy modifies his own static 'fred', and automatic 'wilma' */
int function3( int parm )
{
   static int fred = 100;  /* 'static' fred retains value across calls */
   int i = 100;            /* 'automatic' i does not (reset each call ) */

   printf( "(function3-1) parm=%d, fred=%d i=%d\n\n", parm, fred, i );
   fred += parm;
   i += parm;
   printf( "(function3-2) parm=%d, fred=%d i=%d\n\n", parm, fred, i );

   return( fred );
}