/*

obtain the value with echo $?
*/

#include<stdlib.h>
#include<stdio.h>


int main() {
   

//  return (0);

  return (11);

   
  }
