/*
print_square_function.c
print the square of an integer
*/

#include<stdio.h>


void print_square(int value) {
   printf("%d squared = %d\n", value, value * value);
   return;
}

 
int main(void) {
   int number=0;


   number = 5;
   print_square(number);

   number = 8;
   print_square(number);

   number = 51;
   print_square(number);

   number = 85;
   print_square(85);

return 0;
}
 
