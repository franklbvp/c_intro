
#include <stdio.h>

int show(int x);


int main(){
int val1, val2;
int dval1, dval2;

val1 = -7;
val2 = 13;

show(val1);
show(val2);

// nested call
show(show(val1));

return 0;
}


int show(int x) {
    
   if (x < 0) {
      printf("%d %d\n", x, x*x);
      return x*x;}
   else {
      printf("%d %d\n", x, x*x*x);
      return x*x*x;}
}
