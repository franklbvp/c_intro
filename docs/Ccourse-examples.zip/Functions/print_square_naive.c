/*
print_square_naive.c
print the square of an integer
*/

#include<stdio.h>

   
int main(void) {
   int number=0;


   number = 5;
   printf("%d squared = %d\n", number, number * number);

   number = 8;
   printf("%d squared = %d\n", number, number * number);

   number = 51;
   printf("%d squared = %d\n", number, number * number);

   number = 85;
   printf("%d squared = %d\n", number, number * number);

 
return 0;
}
