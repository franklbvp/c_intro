/*
leapyear.c
A leap year must be divisible by 4 but not by 100, except 
for years divisible by 40, they are also leap years
*/

#include <stdio.h>

int leapyear(int year); 
 
int main()
{
  int res, year;
 
  while (1){
  printf("\n Enter a year to check if it is a leap year\n");
  scanf("%d", &year);
  
  res = leapyear(year);
  if (res == 0) {
     printf(" year %d is not a leap year \n", year);
    }
    else {
     printf(" year %d is a leap year \n", year);
    }
   }

return 0;
}
 
int leapyear(int year) {
// performs the tests ne by one
  if ( year%400 == 0) {
     return 1;
    }
  if (year%100 == 0) {
     return 0;
    }
 
  if (year%4 == 0) {
     return 1;
    }

  return 0;
}

