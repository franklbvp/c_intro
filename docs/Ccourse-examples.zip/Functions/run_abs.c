#include <stdio.h>

int get_largest(int x, int y, int z);


int main(){
int val1, val2, val3;

val1 = -7;
val2 = -13;
val3 = 8;


printf("value = %d  - abs = %d \n", val1, get_abs(val1));
printf("value = %d  - abs = %d \n", val2, get_abs(val2));
printf("value = %d  - abs = %d \n", val3, get_abs(val3));

return 0;
}



int get_abs(int x) {
    
   if (x < 0) {
      return -x;
     }
   else {
      return x;
     }
}
