/* function quad, calculating the square of an integer */



long quad(int x)
{
   return ((long) x * x);
   
}
