#include <stdio.h>

int counter()
{
    static int count;
    return count++;
}

int main(void)
{
    printf("%d ", counter());
    printf("%d ", counter());
    printf("%d ", counter());
    printf("%d ", counter());
    printf("%d ", counter());
    
    return 0;
}
