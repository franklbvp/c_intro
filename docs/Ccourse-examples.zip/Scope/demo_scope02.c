#include<stdio.h>

/*
demo_scope02.c
taken from: http://www.c4learn.com/c-programming/c-file-scope/
*/

void message ();
int num1 = 1;			// Global 

int main ()
{
  int num1 = 6;
  printf ("%d \n", num1);		// Local variable is accessed
  message ();

  return 0;
}

void
message ()
{
  printf ("%d \n", num1);		// Global variable is accessed
}
