/*
static_var.c
static variable
 taken from http://gribblelab.org/cbootcamp/5_Functions.html
*/
#include <stdio.h>

void myFunc(void);
void myFunc2(void);

int main() {
        myFunc();
        myFunc2();
        myFunc();
        myFunc2();
        myFunc();
//      printf("num = %d\n", num);  // THIS WOULD NOT WORK
        return 0;
}
void myFunc(void) {
        static int num = 0;
 //       int num = 0;
        num++;
        printf("myFunc() has been called %d times so far\n", num);
}
void myFunc2(void) {
        int num = 0;
        num++;
        printf("myFunc2() has been called %d times so far\n", num);
}

