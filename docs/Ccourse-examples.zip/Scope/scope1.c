/* External (or global) scope, based on p79 K&R */
#include <stdio.h>
#include <ctype.h> /* for isdigit() */

/* 
 * Declarations of external functions
 */
int getch(void);
int ungetch(int c);

/* 
 * Local function: static for file scope
 */
static int get_int()
/* Read a positive integer from standard input */
{
    int x = 0, c;
    while ((c = getch()) != '\n' && isdigit(c))
        x = 10*x + c - '0'; /* presume ASCII code */
    ungetch(c);
    return x;
}

int main(void)
{
    int n, c;

    printf("Enter integer and any other characters: ");
    
    n = get_int();
    printf("The number was: %d\n", n);
    
    printf("The other chars were: ");
    while ((c = getch()) != '\n')
        putchar(c);
    putchar('\n');

    return 0;
}
