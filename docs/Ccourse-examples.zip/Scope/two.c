/* File two.c */

/* When this file is linked with one.c, functions of this file can access a

test the compilation with / without the extern declaration.
*/

//extern int a;
static int a;

int myfun()
{
   a = 25;   // test this assignment 
   return (a * 10);
}
