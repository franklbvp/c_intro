/* External (or global) scope, based on p79 K&R */
#include <stdio.h> /* for getchar() */

/* 
 * Preprocessor #defines have file scope
 */ 
#define BUFSIZE    100

/*
 * External variables qualified with keyword "static" have file scope
 */
static char buffer[BUFSIZE];    /* buffer for pushed-back characters */
static int bufidx = 0;          /* buffer index */

/*
 * Functions (without static qualifier) have external scope
 */

/* Get a character. */
int getch(void)
{
    if (bufidx > 0) /* get pushed-back data first */
        return buffer[--bufidx];
    return getchar();
}

/* Simulate pushing a character back onto input stream */
int ungetch(int c)
{
    if (bufidx >= BUFSIZE) return -1; /* error: buffer full */
    buffer[bufidx++] = c; 
    return 0; 
}
