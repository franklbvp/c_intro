/* one.c

compilation requires two.c

gcc -o complete one.c two.c
*/

#include <stdio.h>
#include"two.h"

int a;  // global variable

int main(void){

//   int a;   // check the effect of declaring a local to main
   int b;
   a = 2;
   printf("a = %d \n", a);
   b = myfun();
   printf("b = %d \n", b);
   printf("a = %d \n", a);

return 0;
} 	

