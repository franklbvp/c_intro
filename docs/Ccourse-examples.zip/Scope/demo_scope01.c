#include <stdio.h>
// demo_scope01.c

void f(int a);

int a, b;   // global - - test this

void main(void)
{

//int a, b;   // local to main - test this


a = 1;
b = 2;
printf("a = %d, b = %d \n", a, b);
f(a);
printf("a = %d, b = %d \n", a, b);
}

void f(int a)
{
  a = 3;
  {
    int b = 4;
    printf("a = %d, b = %d  \n", a, b);
  }
  printf("a = %d, b = %d  \n", a, b);
  b = 5;
}
