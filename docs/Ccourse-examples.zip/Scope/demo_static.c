#include<stdio.h>

void demo();


int main(void)

{
int i;
for (i=0; i<10; i++)
    demo();

return 0;
}    


void demo()
{
static int total = 0;
//int total = 0;

printf ("in demo \n");
total += 1;
printf ("total = %d\n", total);

}
