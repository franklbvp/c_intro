
/* name hiding */

#include <stdio.h>
#include <string.h>


int x=99;  // a global variable

void my_function1(int x);  // this is another x, not the same one
void my_function2();


int main(){
  char x[5]; // another x, with a different type
  
  strcpy(x, "help");
  printf("this is the value of x in main (string): %s \n", x);
  
  my_function1(5);
  
  my_function2();
  
  return 0;
}

void my_function1(int x){

   printf("this is the value of x inside my_function1 (parameter passed): %d \n", x);
  
  {
    int x; // this is yet another x
	x = 55;
   printf("this is the value of x inside my_function1 (inner block): %d \n", x);
	
  }
   printf("this is the value of x inside my_function1 (after inner block): %d \n", x);

}

void my_function2(){

   printf("this is the value of x inside my_function2 (global): %d \n", x);

}
