/* quad_head.h header quad-func */

long quad(int x);
