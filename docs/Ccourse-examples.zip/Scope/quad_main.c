/* Quad - main */

#include <stdio.h>
#include "quad_head.h"

main ()

{
int x;

printf (" enter a number:");
scanf("%d", &x);
printf (" \n square of %d = %ld \n",x, quad(x));

}
