#include<stdio.h>
#include<math.h>

/*
demo_global.c
taken from Gonzalez, computer programming in C for beginners
*/

void dist(double x1, double y1, double x2, double y2);
double square(double x);

double distance = 0.0; // global variable defined outside of any function

int main()
{
double x_one = 5.37, y_one = 9.6, x_two = 11.16, y_two = 21.78;
dist(x_one, y_one, x_two, y_two);
printf("The distance between the two points is %lf \n", distance);
return 0;
}

void dist(double x1, double y1, double x2, double y2)
// dist() doesn’t return anything
// It sets the value of the global distance directly
{
distance = sqrt(square(x1-x2) + square(y1-y2));
// variable distance is global
}

double square(double x)
{
double y = 0.0;
y = x * x;
return y;
}