#include <stdio.h>

int modify(int, int);

int x=1, y=3, z=5; /* external variables */

int main(void)
{
    int x, z=0; /* local scope 1 */

    x = y + 1;
    while (x++ < 10) {
        int x, y = 0; /* local scope 2 */
        x = z % 5;
        printf("In loop \tx= %d\ty= %d\tz= %d\n", x, y++, z++);
    }

    printf("Before modify()\tx= %d\ty= %d\tz= %d\n", x, y, z);
    z = modify(x, y);
    printf("After modify()\tx= %d\ty= %d\tz= %d\n", x, y, z);
}

int modify(int a, int b)
{
    z += a + b;
    return z;
}
