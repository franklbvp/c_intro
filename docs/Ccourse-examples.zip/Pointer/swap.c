/* 
swap.c
Swap two variables */

#include <stdio.h>

void swap(double * px, double * py);


int main (void)
{
    double a = 5, b = 10; 

    printf("a = %f, b = %f\n", a, b);
    printf("address a = %p, address b = %p\n", &a, &b);
    swap(&a, &b);
    printf("address a = %p, address b = %p\n", &a, &b);
    printf("a = %f, b = %f\n", a, b);

    return 0;
}

void swap(double * px, double * py)
{
    double t = *px;
    *px = *py;
    *py = t;
}
