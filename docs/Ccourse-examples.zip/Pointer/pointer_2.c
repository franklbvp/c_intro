#include <stdio.h>


main()
{
int x = 1, y = 2, z[10];
int *ip;  /* ip points to int */

ip = &x;   /* ip points to x */
y = *ip;   /* y is 1 */
*ip = 0;   /* x is 0 */
ip = &z[0];  /* ip points to z[0] */

printf(" x = %d, y = %d, ip = %p, ip(x) = %p \n", x, y, ip, ip);

}
