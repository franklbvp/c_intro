#include<stdio.h>

 
int
main ()
{
  
int myMatrix[2][4] = { {1,2,3,4} , {5,6,7,8} };

printf("sizeof int = %d \n", sizeof(int));
printf("address myMatrix = %p \n",myMatrix);
printf("myMatrix[0] = %p \n",myMatrix[0]);
printf("content *myMatrix[0] = %p \n",*myMatrix[0]);
printf("content *(myMatrix+0) = %p \n",*(myMatrix+0));
printf("myMatrix[1] = %p \n",myMatrix[1]);
printf("myMatrix + 1 = %p \n",myMatrix+1);

printf("address of myMatrix[1][2] = %p \n", &myMatrix[1][2]);
printf("myMatrix[1][2] = %d \n", myMatrix[1][2]);
printf("*(myMatrix[1]+2) = %d \n", *(myMatrix[1]+2));
printf("(*(myMatrix+1)) = %p \n", (*(myMatrix+1)));
printf("(*(myMatrix+1))[2] = %d \n", (*(myMatrix+1))[2]);

return 0;

}