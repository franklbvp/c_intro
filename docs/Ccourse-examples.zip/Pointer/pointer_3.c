#include <stdio.h>
int main()
{
int i;
int *p1; /* pointer to int */
char *p2; /* pointer to char */


p1 = &i;     /* address in p1 */
printf("enter value for i:");
scanf( "%d", p1);  /* read integer value for i */
p2 = &i;    /* warning message? */

printf("%d %d %d \n",i,*p1, *p2);

}
