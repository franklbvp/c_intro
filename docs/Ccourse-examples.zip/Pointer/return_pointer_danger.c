#include <stdio.h>
// return_pointer_danger.c

int * dangerous(void);

int
main () 
 { 
int *ptr;

*dangerous() = 12;
  
return 0;

}


 
int * dangerous(void)
{
int n;
return &n;          /* NO! */
}