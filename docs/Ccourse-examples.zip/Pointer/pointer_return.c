#include <stdio.h>
#include <stdlib.h>

/*
pointer_return.c
taken from Computer programming in C for beginners
*/

int *test (int);		// the prototype
int add_and_multiply (int x, int y, int *prod_p);


int
main ()
{
  int var1 = -20;
  int var2;
  int sum;
  int prod;

  int *ptr1 = NULL;
  int *ptr2 = NULL;

  ptr1 = test (var1);
  printf ("This is what we got back in main()-pointer: %p \n", ptr1);
  printf ("This is what we got back in main()-value: %d \n", *ptr1);

  var2 = 199;
  sum = add_and_multiply (5, 7, &prod);
  printf ("5 + 7 = %d, 5 * 7 = %d \n", sum, prod);

  ptr2 = test (-99);
  printf ("This is what we got back in main()-pointer: %p \n", ptr2);
  printf ("This is what we got back in main()-value: %d \n", *ptr2);

  printf ("This is the content where ptr1 is pointing to: %d \n", *ptr1);

  return 0;
}

int *
test (int k)
{
  int y = abs (k);
  int *ptr = &y;
  printf ("The value of y in test() directly is %d \n", y);
  printf ("The value of y in test() indirectly is %d \n", *ptr);
  return ptr;
//return &y;
}

int
add_and_multiply (int x, int y, int *prod_p)
{
  *prod_p = x * y;
  return x + y;
}
