#include <stdio.h>
#include <stdlib.h>

/*
pointer_return.c
taken from Computer programming in C for beginners
*/

int * test(int); // the prototype
int main()
{
int var = -20;
int * ptr = NULL;
ptr = test(var);
printf("This is what we got back in main()-pointer: %p \n", ptr);
printf("This is what we got back in main()-value: %d \n", *ptr);
return 0;
}

int * test(int k)
{
int y = abs(k);
int * ptr1 = &y;
printf("The value of y in test() directly is %d \n", y);
//printf("The value of y in test() indirectly is %d \n", *ptr1);
return ptr1;
//return &y;
}
