/*
taken from https://th.physik.uni-frankfurt.de/~mwagner/

read data and store these
*/  
#include<stdio.h>

double plusone(double x)
{
return x + 1.0;
}

double doubleit(double x)
{
return x*x;
}

void apply_function_and_print_result(double (*func)(double), double x)
{
double func_x = (*func)(x);
printf("x = %f func(x) = %f\n", x, func_x);
}

int main(void)
{
apply_function_and_print_result(plusone, 3.0);
apply_function_and_print_result(doubleit, 3.0);
return 0;
}