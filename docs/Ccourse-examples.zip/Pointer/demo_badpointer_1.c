#include <stdio.h>
int main()
{
int i, j;
int *p; /* pointer naar int */
/*
p = &i;
*/
*p = 5;
j = i = 5;
printf("%d %d %d \n",i,j,*p);
}
