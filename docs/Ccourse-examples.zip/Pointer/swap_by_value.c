/* 
swap_by_value.c
Swap two variables - no pointers*/

#include <stdio.h>

void swap(double x, double y);


int main(){

    double a = 5, b = 10; 

    printf("a = %f, b = %f\n", a, b);
    swap(a, b);
    printf("a = %f, b = %f\n", a, b);

    return 0;
}


void swap(double x, double y)
{
    double t = x;
    x = y;
    y = t;
}
