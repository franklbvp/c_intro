#include<stdio.h>
/*
const_pointer.c
constant pointer: A constant pointer is a pointer that cannot change the address its holding. 
Once a constant pointer points to a variable then it cannot point to any other variable.
*/

int main(void)
{
    int var1 = 0;
    int var2 = 0;
    const int * const ptr = &var1;
 
    printf("var1 pointed by ptr = %d\n", *ptr);
 //   *ptr = 10; 
    printf("var1 pointed by ptr = %d\n", *ptr);

//    ptr = &var2;  // try compiling

    return 0;
}
