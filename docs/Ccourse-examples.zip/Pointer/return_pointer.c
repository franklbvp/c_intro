#include <stdio.h>
// return_pointer.c

 int *abc ();			// this function returns a pointer of type int

int
main () 
 { 
int *ptr;
  
ptr = abc ();
  
printf (" pointer returned %p pointing to value %d \n", ptr, *ptr);
  
ptr = abc ();
  
printf (" pointer returned %p pointing to value %d \n", ptr, *ptr);
  
return 0;

}


 
int *
abc () 
 { 
int x = 100;
int * p;

p = &x;  
printf (" in abc - value = %d \n", x);
  
return p;

}
