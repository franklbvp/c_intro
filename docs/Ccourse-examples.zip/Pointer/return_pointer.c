#include <stdio.h>

int *abc(); // this function returns a pointer of type int
 
int main()
{
    int *ptr;
    ptr = abc();
	printf(" pointer returned %p pointing to value %d \n", ptr, *ptr);
    ptr = abc();
	printf(" pointer returned %p pointing to value %d \n", ptr, *ptr);
    return 0;
}
 
int *abc()
{
    int x = 100, *p;
    p = &x;
	printf(" in abc - pointer p %p is pointing to %d \n", p, x);
    return p;
}