#include <stdio.h>

#define BUFSIZE 256

int main(void)
{
    char str[BUFSIZE];
    double fval;
    int ival;

    /* get input */
    printf("Input an int, a float, and a string: ");
    scanf("%d%lf%s", &ival, &fval, str);

    /* echo input */
    printf("You input: %d %f %s\n", ival, fval, str);

    return 0;
}
