#include <stdio.h>
// pointer_4.c
int main()
{

int m=3, n=100, * p;

p=&m;
printf("m is %d\n",*p);
m++;
printf("m is now %d\n",*p);
p=&n;
printf("n is %d\n",*p);
*p=500;
printf("n is now %d\n", n);

}
