/*

*/

#include <stdio.h>
 

int main () {

   int s[4], t[4];
   int i, u=0;
   int *ip = &i, *up = &u, *sp= s, *tp = t;

   printf("address i %p \n", ip);
   printf("address u %p \n", up);
   printf("address s %p \n", sp);
   printf("address t %p \n", tp);

   for (i=0; i<=4; i++){
      s[i] = i;
      t[i] = i;
   }
   printf("s:t\n");
   for (i=0; i<=4; i++){
      printf("%d:%d\n",s[i], t[i]);
   }
   printf("u=%d\n", u);

    
   return 0;
}
