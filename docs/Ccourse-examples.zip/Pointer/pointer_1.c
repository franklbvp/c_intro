/*
pointer_1.c
http://gribblelab.org/cbootcamp/8_Pointers.html
*/
#include <stdio.h>

int main ()
{
  int age = 30;
  int * p;

  p = &age;

  printf("age=%d\n", age);
  printf("sizeof(age)=%ld\n", sizeof(age));

  printf("p=%p\n", p);
  printf("*p=%d\n", *p);
  printf("sizeof(p)=%ld\n", sizeof(p));

  *p = 40;
  printf("*p=%d\n", *p);
  printf("age=%d\n", age);

  age = 50;
  printf("*p=%d\n", *p);
  printf("age=%d\n", age);


  return 0;
}
