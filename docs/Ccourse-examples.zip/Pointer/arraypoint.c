#include <stdio.h>

/* Show that array names are converted to pointers when passed to a function. */
void array_func(short x[], short* y)
{
    printf("x = %p, &x = %p, &x[0] = %p, sizeof(x) = %d\n", x, &x, &x[0], sizeof(x));
    printf("y = %p, &y = %p, &y[0] = %p, sizeof(y) = %d\n", y, &y, &y[0], sizeof(y));
}

/* Show that an array name is *different* to a pointer. */
int main (void)
{
    short z[10];

#if 0    
    short tmp[10];
    z = tmp; 
    ++z; 
#endif

    printf("z = %p, &z = %p, &z[0] = %p, sizeof(z) = %d, sizeof(z+0) = %d\n", 
        z, &z, &z[0], sizeof z, sizeof(z+0));
    array_func(z, z);

    printf("z+1 = %p, &z+1 = %p, &z[0]+1 = %p\n", z+1, &z+1, &z[0]+1);
}
