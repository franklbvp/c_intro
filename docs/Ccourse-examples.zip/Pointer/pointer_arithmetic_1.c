#include <stdio.h>
/*
pointer_arithmetic_1.c
https://www.geeksforgeeks.org/pointer-arithmetics-in-c-with-examples/
*/  
#include <stdio.h> 
  
// Driver Code 
int main() 
{ 
    // Integer variable 
    int N = 4; 
  
    // Pointer to an integer 
    int *ptr1, *ptr2; 
  
    // Pointer stores 
    // the address of N 
    ptr1 = &N; 
    ptr2 = &N; 
 
    printf("sizeof(int): %ld\n", sizeof(int)); 
    printf("Pointer ptr1 before Increment: "); 
    printf("%p \n", ptr1);
    printf("content of memory ptr1 pointing at: %d \n", *ptr1);
    ptr1++;     // Incrementing pointer ptr1;
    printf("Pointer ptr1 after Increment: "); 
    printf("%p \n", ptr1); 
    printf("content of memory ptr1 pointing at: %d \n\n", *ptr1);
  
    printf("Pointer ptr2 before Decrement: "); 
    printf("%p \n", ptr2); 
    printf("content of memory ptr2 pointing at: %d \n", *ptr2);
    ptr2--; // Decrementing pointer ptr2
    printf("Pointer ptr2 after Decrement: "); 
    printf("%p \n", ptr2); 
    printf("content of memory ptr2 pointing at: %d \n\n", *ptr2);
  
    return 0; 
} 
