#include <stdio.h>
int main()
{

int *p; /* pointer naar int */

printf("geef een geheel getal in");
scanf("%d", p);
printf("ingelezen getal is %d \n",*p);
}
