#include<stdio.h>
int max (int x, int y);
int min (int x, int y);
 int
main ()
{
  int a = 5, b = 2;
  int (*fp) (int, int);
   fp = &max;
  printf ("maximum of %d and %d =  %d \n", a, b, (*fp) (a, b));
   fp = &min;
  printf ("minimum of %d and %d =  %d \n", a, b, (*fp) (a, b));
  return 0;
}

int
max (int x, int y)
{
  if (x > y)
    return x;
  else
    return y;
}

int
min (int x, int y)
{
  if (x < y)
    return x;
  else
    return y;
}


