#include<stdio.h>
/*
pointer_to_const.c
This type of pointer can change the address it is pointing to 
but cannot change the value kept at those addresses.
*/

int main(void)
{
    int var1 = 0;
    int var2 = 100;
    const int *ptr = &var1;

    var1 = 6;
    printf("%d\n", *ptr);

    *ptr = 1;   // try compiling this line
    var1 = 1;
    printf("%d\n", *ptr);

    ptr = &var2;
    printf("%d\n", *ptr);
 
    return 0;
}
