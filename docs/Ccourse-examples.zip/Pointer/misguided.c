#include <stdio.h>
#include <string.h>

/* Incorrect string duplication function */
char *string_duplicate(const char *s)
{
//    static char buffer[255]; keep the data alive!
    char buffer[255];
    strcpy(buffer, s);
    return buffer;
}

int main (void)
{
    char * message = "Hello World!\n";
    char * duplicate;

    duplicate = string_duplicate(message);
    printf("Original:  %s <> Duplicate: %s \n", message, duplicate);

    return 0;
}
