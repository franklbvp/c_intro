#include<stdio.h>
// return_pointer_danger_2.c
// https://overiq.com/c-programming-101/returning-a-pointer-from-a-function-in-c/

int *abc(); // this function returns a pointer of type int
int fabc(int a);

int main()
{
    int b;
    int *ptr;
    ptr = abc(10);
    printf("pointer pointing to %p - value %d \n", ptr, *ptr);
    b = fabc(23);
    printf("pointer pointing to %p - value %d \n", ptr, *ptr);
    printf("b - value %d \n", b);
    return 0;
}

int *abc(int a)
{
    int x, *p;
    x = a;
    p = &x;
    return p;
}

int fabc(int a)
{
    int x;
    x = a;
    return x + x;
}