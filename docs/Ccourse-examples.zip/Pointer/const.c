#include <stdio.h>

void cannot_change(const double *array, int len)
/* May perform read-only operations on array */
{
    int i;
    double tmp; 

    for (i = 0; i<len; ++i) {
        *(array + i) = 3.2; /* Invalid. */
        array[i] = 5.4;     /* Invalid. */
        tmp = array[i] * 2;
        printf("%9.3f\t %.3f\n", array[i], tmp); /* Valid. */
    }
}

int main(void)
{
    double values[] = {54.2, 12.643, 5654, 9.34, 123, -34.7};
    int nvals = sizeof(values)/sizeof(values[0]);

    cannot_change(values, nvals);

    return 0;
}
