/*
genearte_array.c
test function to generate an array
*/

#include<stdio.h>

void generate_array(int size, int dummy[], int x);

int main() {

int i;
int dummy1[10];
int dummy2[5];

generate_array(10, dummy1, 100);
for (i=0; i<10; i++)
  printf("dummy1 - %d = %d \n", i, dummy1[i]);

generate_array(5, dummy2, 33);
for (i=0; i<5; i++)
  printf("dummy1 - %d = %d \n", i, dummy2[i]);

return 0;
}

void generate_array(int size, int dummy[], int x)
{
int i; 

for (i=0; i<size; i++){
   dummy[i] = i + x;
  }
}

