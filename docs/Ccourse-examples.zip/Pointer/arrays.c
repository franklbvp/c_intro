#include <stdio.h>
/* Demo array arithmetic */

int main(void)
{
    char a[] = {1, 2, 3, 4, 'a', 'b', 'c'};
    int b[10] = {1, 2, 3, 4, 'a', 'b', 'c'};
    int i, N;
    char *pa;
    int *pb;

    /* Size of various variables */
    printf("Sizes: a=%d b=%d pa=%d pb=%d\n\n", sizeof(a), sizeof(b), sizeof(pa), sizeof(pb));

    /* Print contents of a, method 1 */
    N = sizeof(a)/sizeof(a[0]);
    for (i = 0; i < N; ++i)
        printf("%d ", a[i]);
    printf("\n\n");

    /* Print contents of a, method 2 */
    for (pa = a; pa != a + N; ++pa)
        printf("%d ", *pa);
    printf("\n\n");

    /* Print contents of b */
    for (i = 0; i < sizeof(b)/sizeof(b[0]); ++i)
        printf("%d ", *(b+i));

    return 0;
}
