#include <stdio.h>

int *retpoint();

int main()
{
int *p; /* pointer naar int */

p = retpoint();
*p = 8;

printf("%d  \n",*p);
}

int *retpoint()
{
int temp;

return (&temp);
}
