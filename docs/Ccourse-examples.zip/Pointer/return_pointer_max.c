#include <stdio.h>
// return_pointer_max.c
// https://cs.brynmawr.edu/Courses/cs246/spring2014/Slides/10_Pointer_Array.pdf

int * max(int * x, int * y);

int
main () 
 { 
int a = 1, b = 2; 
int *ptr;
  
ptr = max(&a, &b);
  
printf (" pointer returned %p pointing to max value %d \n", ptr, *ptr);
  
return 0;

}
 
int * max(int * x, int * y)
 { 
if (*x > *y)
   return x;
return y;  
}