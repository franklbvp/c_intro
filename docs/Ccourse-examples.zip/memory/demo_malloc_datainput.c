/*
taken from https://th.physik.uni-frankfurt.de/~mwagner/

read data and store these
*/  
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
  int
main (void) 
{
  int i1;			// loop counter
  char string1[1000];
  int n;			// number of experiments-data
  printf ("Enter the number of data points: \n");
  scanf ("%d", &n);
   if (n <= 0)
    
    {
      printf ("n must be larger than 0 \n");
      exit (0);
    }
   double *data;
   if ((data = (double *) malloc (n * sizeof (double))) == NULL)
    
    {
      printf ("malloc cannot provide the memory space!\n");
      exit (0);
    }
   for (i1 = 0; i1 < n; i1++)
    
    {
      printf ("Data %d: ", i1);
      scanf ("%lf", data + i1);	// 
    }
   
// ********************
    for (i1 = 0; i1 < n; i1++)
    printf ("data[%d] = %f\n", i1, data[i1]);
   
// ********************
    while (1)
    
    {
      printf ("Do you want to continue to enter data (yes/no)? ");
      scanf ("%s", string1);
       if (strcmp (string1, "no") == 0)
	break;
       if (strcmp (string1, "yes") != 0)
	continue;
       
// **********
// Read more data
      int delta_n;
      printf ("Enter the number of data points: \n ");
      scanf ("%d", &delta_n);
       if (delta_n <= 0)
	
	{
	  printf ("Number of extra data points must be > 0 \n");
	  exit (0);
	}
       if ((data =
	      (double *) realloc ((void *) data,
				  (n + delta_n) * sizeof (double))) == NULL)
	
	{
	  printf ("Error, realloc is not able to reserver memory!\n");
	  exit (0);
	}
       for (i1 = n; i1 < n + delta_n; i1++)
	
	{
	  printf ("Data point %d: ", i1);
	  scanf ("%lf", data + i1);	
	}
       n += delta_n;
       
// **********
	for (i1 = 0; i1 < n; i1++)
	printf ("data[%d] = %f\n", i1, data[i1]);
    }
   
// ********************
    
    free (data);
  data = NULL;
}
