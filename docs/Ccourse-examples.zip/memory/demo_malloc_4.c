/*
demo_malloc_4.c
http://anee.me/dynamic-memory-allocation-in-c/
*/

#include <stdio.h>
#include <stdlib.h> // for access to the memory allocation functions
 
#define NO_OF_CHARS 20
 
int main()
{
 void * upper_bound; // To avoid invalid reads.
 char * char_ptr;

 // Tip 1: Always cast the returned pointer from malloc, Most of the compilers are kind enough to give you warnings for that.
 // Tip 2: Always check the output of malloc
 char_ptr = (char *)malloc(sizeof(char) * (NO_OF_CHARS + 1)); // we need an extra byte for the NULL, same as "char array[NO_OF_CHARS]"
 
 if (char_ptr == NULL) {
    printf("Failed to allocate memory for chars.");
 }
 
 // char_ptr
 upper_bound = char_ptr + NO_OF_CHARS;
 
for (; char_ptr < (char *)upper_bound; char_ptr++) {
    *char_ptr = 'a';
 }
 *char_ptr = '\0'; // terminate the string
 printf("This should display a string of %d A's : %s\n", NO_OF_CHARS, char_ptr - NO_OF_CHARS);
 
// Tip 3: Always free your pointers
 free(char_ptr - NO_OF_CHARS);

 // Note: Free takes in the address of the start of the memory block you allocated. (the one returned by malloc)
 // if you input any other memory location. It will result in crash.
 
 return 0;
}
