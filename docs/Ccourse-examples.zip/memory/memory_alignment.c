/*
check the alignment in memory
*/
#include<stdio.h>

int main() {
char x; 
int i;  
short s; 
char y;

printf("x is allocated at %p  - size of char %ld \n", &x, sizeof(x));
printf("i is allocated at %p  - size of int %ld  \n", &i, sizeof(i));
printf("s is allocated at %p  - size of short %ld \n", &s, sizeof(s));
printf("y is allocated at %p  - size of char %ld \n", &y, sizeof(y));

return 0;
}