/* 
demo-calloc.c

Using calloc() to initialize 100 floats to 0.0 */

#include <stdlib.h>
#include <stdio.h>
#define BUFFER_SIZE 100

int main(){
float * buffer;
int i;

if ((buffer = (float*)calloc(BUFFER_SIZE, sizeof(float))) == NULL){
	printf("out of memory\n");
	exit(1);
	}

for (i=0; i < BUFFER_SIZE; i++)
	printf("buffer[%d] = %f\n", i, buffer[i]);

return 0;
}
