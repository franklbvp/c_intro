 /*
 http://www.mathcs.emory.edu/~cheung/Courses/255/Syllabus/2-C-adv-data/dyn-array.html
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *create_string_1();

int main()
   {
       int i;
	   char *pointstr;
       double *p;    // We uses this reference variable to access
   		     // dynamically created array elements
    
       p = calloc(10, sizeof(double) );  // Make double array of 10 elements
	   if (p == NULL) exit(1);
    
       for ( i = 0; i < 10; i++ )
   	  *(p + i) = i;            // put value i in array element i
    
       for ( i = 0; i < 10; i++ )
   	  printf("*(p + %d) = %lf  - position %p \n", i, *(p+i), (p+i) );
    
    
       free(p);      // Un-reserve the first array
    
       putchar('\n');
    
       p = calloc(4, sizeof(double) );  // Make a NEW double array of 4 elements    
       if (p == NULL) exit(1);
       // ***** Notice that the array size has CHANGED !!! ****

       for ( i = 0; i < 4; i++ )
   	  *(p + i) = i*i;            // put value i*i in array element i
    
       for ( i = 0; i < 4; i++ )
   	  printf("*(p + %d) = %lf - position %p \n", i, *(p+i), (p+i) );
    
       free(p);      // Un-reserve the second array
       putchar('\n');
	   
	pointstr = create_string_1();
	printf("String = %s,  Address = %p\n", pointstr, pointstr);
	free(pointstr);

	   
return 0;}

char *create_string_1()
{

   /* Initial memory allocation 
   this memory stays available
   */
   char *pstr;
   pstr = (char *) malloc(15);
   if (pstr == NULL) exit(1);
   strcpy(pstr, "my string");
   
   return pstr;

 }