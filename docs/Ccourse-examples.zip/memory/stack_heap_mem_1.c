/*

https://craftofcoding.wordpress.com/2015/12/07/memory-in-c-the-stack-the-heap-and-static/
*/

#include <stdio.h>
#include <stdlib.h>


int x;          

int main(void) 
{
    int y;   
    char *str; 

    y = 4;
    printf("stack memory y: %d\n", y);
    printf("location y: %p\n", &y);

    x = 44;
    printf("global variable x: %d\n", x);
    printf("location x: %p\n", &x);


    str = malloc(100*sizeof(char)); 
    str[0] = 'm';
    printf("heap memory: %c\n", str[0]); 
    printf("location heap memory: %p\n", &str[0]); 
    free(str);          

    return 0;
}