/*
demo_realloc.c

http://anee.me/dynamic-memory-allocation-in-c/

*/
#include <stdio.h>
#include <stdlib.h> // for access to the memory allocation functions
 
#define NUMBER_NEW_INTS 10
// Try to fiddle with this value, and you'll notice that
// for small values, you'll get the same memory location back
// from realloc with an extended size.
 
int main()
{
 int *int_ptr;
 int *temp_ptr; // for realloc
 
 int_ptr = (int *)malloc(sizeof(int));
 int_ptr_orig = int_ptr;
 
 if (int_ptr == NULL) {
 printf("Failed to allocate memory for");
 return -1;
 }
 
 printf("Allocated a memory block for 1 int @ %p.\n", int_ptr);
 
 // Tip: Always use a temp pointer with realloc.
 // Reason :-
 // If realloc fails to get a new block it will return NULL, which will
 // overwrite your ptr and result in a memory leak because the previous memory
 // location which we allocated with malloc (or calloc) would still be unfreed.
 temp_ptr = realloc((void *)int_ptr, sizeof(int) * NUMBER_NEW_INTS); // please give me some more memory
 if (temp_ptr == NULL) {
 // Can't get any memory
 free(int_ptr_orig);
 return -1;
 }
 // Now you are safe to overwrite int_ptr
 
 int_ptr = temp_ptr;
 printf("Allocated a memory block for %d int(s) @ %p.\n", NUMBER_NEW_INTS + 1, int_ptr);
 
 free(int_ptr);
 return 0;
}