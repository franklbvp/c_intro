#include <stdio.h>
#include <stdlib.h>
// demo_malloc_1.c

int main(){
	int *p;
  /* Allocate 4 bytes */
	p = (int *) malloc( sizeof(int) );
  if (p == 0)
	{
		printf("ERROR: Out of memory\n");
		return 1;
	}
  printf("enter an integer");
  scanf("%d", p);
  printf("content = %d    address = %p \n", *p, p);
  /* This returns the memory to the system.*/
	free(p);	
}
