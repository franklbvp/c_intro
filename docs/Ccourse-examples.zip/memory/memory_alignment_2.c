/*
check the alignment in memory
*/
#include<stdio.h>

int main() {


int q = 10;
int s = 5;
int a[3];

printf("Address of a: %p\n",    a);
printf("Address of a[1]: %p\n", &a[1]);
printf("Address of a[2]: %p\n", &a[2]);
printf("Address of q: %p\n",    &q);
printf("Address of s: %p\n",    &s);


return 0;
}