/*
demo_malloc_3.c
http://anee.me/dynamic-memory-allocation-in-c/
*/

#include <stdio.h>
#include <stdlib.h> // for access to the memory allocation functions
 
#define NO_OF_INTS 5
#define NO_OF_CHARS 20
#define NO_OF_LONGS 5
 
int main()
{
 void * upper_bound; // To avoid invalid reads.
 int * int_ptr;
 char * char_ptr;

 // Tip 1: Always cast the returned pointer from malloc, Most of the compilers are kind enough to give you warnings for that.
 int_ptr = (int *)malloc(sizeof(int) * NO_OF_INTS); // same as "int array[NO_OF_INTS]"
 
 // Tip 2: Always check the output of malloc
 if (int_ptr == NULL) {
    printf("Failed to allocate memory for ints.");
 return -1;
 }
 
 char_ptr = (char *)malloc(sizeof(char) * (NO_OF_CHARS + 1)); // we need an extra byte for the NULL, same as "char array[NO_OF_CHARS]"
 
 if (char_ptr == NULL) {
    printf("Failed to allocate memory for chars.");
 }
  // Now, we have 2 pointers each pointing to the start (array[0]) of their respective allocated memory blocks.
  // Let's populate the memory blocks
 
 printf("Notice the intervals in the addresses.\n");
 // int_ptr
 upper_bound = int_ptr + NO_OF_INTS;
 
 for (; int_ptr < (int *)upper_bound; int_ptr++) {
 printf("Setting %p to : 1\n", int_ptr);
 *int_ptr = 1;
 }
 
 // char_ptr
 upper_bound = char_ptr + NO_OF_CHARS;
 
for (; char_ptr < (char *)upper_bound; char_ptr++) {
 *char_ptr = 'a';
 }
 *char_ptr = '\0'; // terminate the string
 printf("This should display a string of %d A's : %s\n", NO_OF_CHARS, char_ptr - NO_OF_CHARS);
 
// Tip 3: Always free your pointers
 free(int_ptr - NO_OF_INTS);
 free(char_ptr - NO_OF_CHARS);
 
 // Note: Free takes in the address of the start of the memory block you allocated. (the one returned by malloc)
 // if you input any other memory location. It will result in crash.
 // For proof, try the following :-
 //free(int_ptr);
 //free(int_ptr - NO_OF_INTS);
 //free(char_ptr - NO_OF_CHARS);
 // even one byte off the address would result in a crash.
 
 return 0;
}