/* displays ASCII code for a character 

difference beteween display and storage
*/
#include <stdio.h>
int main(void)
{
char ch;
ch='A';
printf("The code for %c is %d.\n", ch, ch);
return 0;
}