#include <stdio.h>

/*
based on
http://fresh2refresh.com/c/c-printf-and-scanf/
*/
 
int main()
{
   char  ch = 'A';
   char  str[20] = "fresh2refresh.com";
   float flt = 10.234;
   int no = 150; 
   int n = 12345; 
   double dbl = 20.123456;
   double x = .00000123456789;

   printf("Here is no: %d\n", no);
   printf("Here is no: %4d\n", no);            // at least 4 positions
   printf("Here is no: %4d\n", n);             // at least 4 positions
   printf("Here is no: %05d\n", no);           // at least 5 positions fill it up with 0
   printf("Here is no: %i\n\n", no);

   printf("no with the float specification %f \n\n", no);

   printf("a float number %f \n\n", flt);


 /* Display a double three different ways. */

   printf("Here is x: %g\n", x);
   printf("Here is x: %f\n", x);
   printf("Here is x: %15f\n", x);
   printf("Here is x: %20.15f\n", x);
   printf("Here is x: %e\n\n", x);

 
   printf("Double value is %f \n", dbl);
   printf("Double value is %lf \n", dbl);
   printf("Double value is %7.2f \n", dbl);      // at least 7 positions right aligned
   printf("Double value is %-7.2f \n", dbl);     // left aligned
   printf("Double value is %7.5f \n\n", dbl);

   printf("Octal value is %o \n", no);           // octal representation of no
   printf("Hexadecimal value is %x \n\n", no);     // hexadecimal representation of no

   printf("Character is %c \n", ch);             // print a character
   printf("Character is %c \n", str);            // print a character
   printf("String is %s \n\n" , str);              // print a string

   printf("This is a string with \t tabs \t more tabs \n");
   printf("try the new \f page \n");
   printf("hello worl\b\bd\n");
 
   return 0;
 
}
