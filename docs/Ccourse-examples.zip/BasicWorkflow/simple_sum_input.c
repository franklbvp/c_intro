#include <stdio.h>

/*
simple program to show the result of a sum, both operands are given as input

source: GJ Bex
*/ 
  int
main (void)  {  double x, y;
   printf (" enter 2 operands, separated by ,\n");
   
// scanf ("%lf, %lf", &x, &y);
    scanf ("%lf  %lf", &x, &y);
  printf ("%lf + %lf = %lf\n", x, y, x + y);
   return 0;
}


