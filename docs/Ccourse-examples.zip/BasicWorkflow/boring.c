/* Another boring program
 */
#include <stdio.h>

int
main (void)
{

  int i;
  i = 7;

  printf ("hello world!\n");

  printf (" the value of i = %d", i);

  return 0;
}
