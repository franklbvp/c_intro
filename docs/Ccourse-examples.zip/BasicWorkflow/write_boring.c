/* The World's Second-Most Boring C Program
 *   print The World's Most Boring C Program
 *  http://www.cse.psu.edu/~dheller/cmpsc311/Demos/boring/write-boring.c

 * compile with gcc
 * compile with gcc -std=c99

 */

#include <stdio.h>

int main(void)
{
  printf("/* The World's Most Boring C Program\n");
  printf(" *   print octal escape sequences\n");
  printf(" */\n");
  printf("\n");
  printf("#include <stdio.h>\n");
  printf("\n");
  printf("int main(void)\n");
  printf("{\n");

  for (int i = 0; i < 2; i++)
    {
      for (int j = 0; j < 8; j++)
        {
          for (int k = 0; k < 8; k++)
            {
              printf("  printf(\"%d%d%d\");\n", i, j, k);
            }
        }
    }

  printf("\n");
  printf("  return 0;\n");
  printf("}\n");
  printf("\n");

  return 0;
}

