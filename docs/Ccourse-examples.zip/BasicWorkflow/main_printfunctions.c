#include <stdio.h>
/*
main function calling functions
print_text
print_numbers

compile multiple files

gcc -o main_prog  main_printfunctions.c print_text.c  print_numbers.c


*/

void print_text();
void print_numbers();

int main(void) {
  print_text();
  print_numbers();
  return 0;
}
