#include <stdio.h>

/* a comment line 

try to compile this code with the -ansi option

*/

int main(void) {
  printf("hello this is C\n");  // this is a comment c99 style
  return 0;
/*
this is a multiline
comment
*/
}
