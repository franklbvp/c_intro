// using the integer conversion specifiers
// taken from http://www.tenouk.com/Module5.html


#include <stdio.h>

 

int main()

{

      printf("Various format for integer printing\n");

      printf("-------------------------------------\n");

      printf("%d\n",  455);

      printf("%i\n",  455);  //i same as d in printf()

      printf("%d\n",  +455);

      printf("%d\n",  -455);

      printf("%d\n",  320000);  

      printf("%hd\n",  320000);   //h short format

      printf("%ld\n",  2000000000L);

      printf("%o\n",  455);

      printf("%u\n",  455);

      printf("%u\n",  -455);

      //-455 is read by %u and converted to the unsigned

      //value 4294966841 by 4 bytes integer

      printf("%x\n",  455);

      printf("%X\n",  455);

     return 0;

}
