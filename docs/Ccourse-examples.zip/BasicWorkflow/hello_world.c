#include <stdio.h> 

int main(void) {

   printf("hello world!\n"); 
   printf("hello me!\n"); 
   return 0; 
}

