#include <stdio.h>

int main (void)
{
  int i;
  float f;
  char c;

  printf ("Enter an integer and a float, then Y or N\n> ");
  scanf ("%d,%f,%c", &i, &f, &c);  // check the difference in the format specification
//  scanf ("%d-%f-%c", &i, &f, &c);  // check the difference in the format specification
//  scanf ("%d %f %c", &i, &f, &c);
  printf ("You entered:\n");
  printf ("i = %d, f = %f, c = %c\n", i, f, c);

  return 0;
}
