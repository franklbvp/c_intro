#include <stdio.h>

/*
simple program to show the result of a sum, the operands are hardcoded

source: GJ Bex
*/

int main(void) {
    double x, y, z;
    x = 3.2;
    y = -2.1;
    z = x + y;
    printf("%lf\n", z);
}
