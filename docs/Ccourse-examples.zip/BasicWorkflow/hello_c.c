#include <stdio.h>
/*
hello_c.c
here is some comment

*/

int main (void) 
{
  
printf ("Hello,  this is C \n"); // this is 1 line
printf ("Hello,  this is C \n");
printf ("Hello,  this is C \n");
  
return 1;

}

