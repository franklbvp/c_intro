#include <stdio.h>

int main (void) 
{
  
printf ("Hello,  this is C \n");
printf ("Hello,  this is C \n");
  
return 0;

}

