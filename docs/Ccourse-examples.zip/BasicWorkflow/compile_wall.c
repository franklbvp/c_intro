/*
taken from: https://www.csee.umbc.edu/courses/104/fall05/ratsimor/Compiling-C.htm

compile without and with the option -Wall

The incorrect format specifier causes the output to be corrupted, because the function printf is passed an integer instead of a floating-point number. Integers and floating-point numbers are stored in different formats in memory, and occupy different numbers of bytes, leading to a spurious result.

compile with -ansi option to test the // comment
*/
#include <stdio.h>

int
main (void)
{
  printf ("Two plus two is %f\n", 4);  // check with 4 and 4.
  return 0;
}
