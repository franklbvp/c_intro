/*

enter the data manually
enter the data from file (redirect) ./a.out < 2numbers.dat

based on https://th.physik.uni-frankfurt.de/~mwagner/mcwagner.html#progb
*/

#include<stdio.h>

int main(void)
{
printf("Read 2 numbers and calculate the addition \n");

double a;
scanf("%lf", &a);
printf("a = %f\n", a);

double b;
scanf("%lf", &b);
printf("b = %f\n", b);

printf("--> a + b = %f\n", a+b);
}
