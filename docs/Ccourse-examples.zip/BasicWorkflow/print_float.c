// printing floating-point numbers with floating-point conversion specifiers
// taken from http://www.tenouk.com/Module5.html


#include <stdio.h>

 

void main()

{

      printf("Printing floating-point numbers with\n");

      printf("floating-point conversion specifiers.\n");

      printf("Compare the output with source code\n\n");


      printf("1.  %e\n", 123.456789);

      printf("2.  %e\n", +123.456789);

      printf("3.  %e\n", -123.456789);

      printf("4.  %E\n", 123.456789);

      printf("5.  %f\n", 123.456789);
      
      // general format check: https://stackoverflow.com/questions/54162152/what-precisely-does-the-g-printf-specifier-mean

      printf("6.  %g\n", 123.456789);

      printf("7.  %G\n", 123.456789);


      printf("11.  %e\n", 1234567.89);

      printf("12.  %e\n", +1234567.89);

      printf("13.  %e\n", -1234567.89);

      printf("14.  %E\n", 1234567.89);

      printf("15.  %f\n", 1234567.89);
      
      // general format check: https://stackoverflow.com/questions/54162152/what-precisely-does-the-g-printf-specifier-mean

      printf("16.  %g\n", 1234567.89);

      printf("17.  %G\n", 1234567.89);

}
