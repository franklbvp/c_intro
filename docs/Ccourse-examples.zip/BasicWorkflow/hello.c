/* Hello World program */

#include<stdio.h>

main()
{
   printf("Hello World");
   printf("Hello World");
}
