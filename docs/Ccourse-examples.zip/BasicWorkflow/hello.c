/* 
Hello World program 
*/

#include<stdio.h>

int main()
{
   printf("Hello World 1\n");   // print statement
   printf("Hello World 2\n");
   printf("Hello World 3\n");
   printf("Hello World 4\n");
   // more comment
   printf("Hello World ");
   printf("Hello World ");
   printf("Hello World \n");
   printf("Hello World \n");
   return 0;
}
