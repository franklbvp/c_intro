#include <stdio.h>
/*
function printing some text
*/

void print_text(){
   printf("example taken from  Beginning C \n");
   printf("Author: I. Horton \n");
}
