// printing strings and characters
// taken from http://www.tenouk.com/Module5.html


#include <stdio.h>

 

int main()

{

    char character = 'A';

    char string[ ]  =  "This is a string";

    char *stringPtr = "This is also a string";

    printf("---------------------------------\n");

    printf("---Character and String format---\n");

    printf("---------------------------------\n\n");

    printf("%c <--This one is character\n", character);

    printf("\nLateral string\n");

    printf("%s\n", "This is a string");

    printf("\nUsing array name, the pointer to the first array's element\n");

    printf("%s\n", string);

    printf("\nUsing pointer, pointing to the first character of string\n");

    printf("%s\n", stringPtr);

    return 0;

}


