#include <stdio.h>
/*
function printing some numbers
print_numbers
*/
void print_numbers(){
    int i;
    for(i=0; i<10; i++){
 
        printf("Number  %i---\n",i);
        }
		
}
