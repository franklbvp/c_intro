#include <stdio.h>

int main(void)
{
system("clear");     // use linux system command to clear the screen
printf("Hello this is C \n");
return 0;
}
