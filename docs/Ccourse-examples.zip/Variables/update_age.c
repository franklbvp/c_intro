#include <stdio.h>

/*
taken from https://portal.tacc.utexas.edu/-/c-programming-basics
*/

int main(){
int age;
age = 10;
printf("Initial value of age is: %d\n", age);
age = 20;
printf("Updated value of age is: %d\n", age);
age = age + 20;
printf("New updated value of age is: %d\n", age);
return 0;
}
