#include <stdio.h> 

/* 
source: http://c.happycodings.com/code-snippets/code30.html
*/ 
  int
main () 
{
  enum Days
  { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday };
   enum Days TheDay;
   int j = 0;
  printf ("Please enter the day of the week (0 to 6)\n");
  scanf ("%d", &TheDay);
  
   if (TheDay == Sunday || TheDay == Saturday)
    printf ("Hurray it is the weekend\n");
  
  else
    printf ("Curses still at work\n");
   return 0;
}


