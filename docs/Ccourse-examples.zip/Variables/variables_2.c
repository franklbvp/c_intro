/* variables_1.c */

/* compile gcc -Wall -o variables_1  variables_1.c */

#include <stdio.h>


int main () 
{
  int ii, jj;
  float fr1, fr2;

  ii = 1.8;
  printf (" ii = %22.16e \n", ii);

  ii = 1.9;
  printf (" ii = %d \n", ii);

  jj = ii * 10;
  printf (" jj = %d \n", jj);

  fr1 = ii * 10;
  printf (" jj = %22.16e \n", fr1);


  fr2 = ii * 10.0;
  printf (" jj = %22.16e \n", fr2);

  return 0;
}