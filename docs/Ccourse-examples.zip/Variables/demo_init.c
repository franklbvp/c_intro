/* demo_init.c */

#include <stdio.h>


int main()
{
unsigned int value = 2500;
//unsigned int value = -/+2500;
double val;

printf("value %d \n", value);
printf("val %g \n", val);

val = value * 2;

printf("val %g \n", val);

val = (double) value * 2;

printf("val %g \n", val);

val = value + 5000;

printf("val %g \n", val);

val = value + 5000.0;

printf("val %g \n", val);

return 0;
}

