/* short_overflow.c  										 */

#include <stdio.h>
#include <limits.h>

int main (void)

{

/* check both versions with signed and unsigned integer - recompile */
short counter;
//unsigned short counter;
int i;

  printf("Size of short max %d\n", SHRT_MAX);

  counter = 0;
  for (i=0; i<=25; i +=1)
     {
     counter = i * 5000;
     printf("i = %d --- counter = %d \n", i, counter);
     }
return 0;
}
