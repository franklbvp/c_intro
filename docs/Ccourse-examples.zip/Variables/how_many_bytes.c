/*
   how_many_bytes.c
*/

#include <stdio.h>

int main(void) {
        printf("a char is %ld bytes\n", sizeof(char));
        printf("an int is %ld bytes\n", sizeof(int));
        printf("an float is %ld bytes\n", sizeof(float));
        printf("a double is %ld bytes\n", sizeof(double));
        printf("a short int is %ld bytes\n", sizeof(short int));
        printf("a long int is %ld bytes\n", sizeof(long int));
        printf("a long long is %ld bytes\n", sizeof(long long));
        printf("a long double is %ld bytes\n", sizeof(long double));
        return 0;
}

