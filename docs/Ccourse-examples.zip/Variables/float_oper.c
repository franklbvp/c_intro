/*
 based on https://followtutorials.com/2019/03/c-program-to-illustrate-the-use-of-arithmetic-operators-in-floating-point-number.html
*/

#include <stdio.h>
#include <math.h>
 int main() 
{
 float r1, r2,mul,sum, div, rem, sub, rpow; 

// first number;
r1 = 1.2; 
// second number
r2 = 0.33;

printf("First number: %f \n", r1);
printf("Second number: %f \n", r2);
sum=r1+r2; 
printf("The sum of given two numbers is:%f\n",sum); 
mul=r1*r2;
printf("The multiplication of two numbers is:%f\n", mul); 
div = r1/r2; 
printf("The division of two numbers is:%f\n", div); 
sub=r1-r2; 
printf("The subtration of rwo numbers is:%f\n", sub);
rpow=pow(r1,r2);
printf("The power of %g to  %g is= %g \n", r1, r2, rpow);

return 0;
 }