/* Program to demonstrate the working of arithmetic operators in C.  
   based on http://www.programiz.com/c-programming/c-operators
*/
#include <stdio.h>
int main(){
    int a,b,c;

    a = 9;
    b = 5;

    c=a+b;
    printf("a+b=%d\n",c);
    c=a-b;
    printf("a-b=%d\n",c);
    c=a*b;
    printf("a*b=%d\n",c);
    c=a/b;
    printf("a/b=%d\n",c);
    c=a%b;
    printf("Remainder when a divided by b=%d\n",c);
    return 0;
}
