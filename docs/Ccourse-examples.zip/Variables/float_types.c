/* float_types.c  										 */
/* different types are shown, together with their limits */

#include <stdio.h>
#include <float.h>

void main ()

{
/* demo_float_types */

  float f = 30.05;
  float f2 = 30.05*100;
  printf("value of FLOAT f = %g\n", f);
  printf("value of FLOAT f2 = %g\n", f2);
  f = f * 100;
  printf("value of FLOAT f (multiplied with 100) = %g\n", f);

  printf("Value of FLOAT Max %e\n", FLT_MAX);
  printf("Value of FLOAT Min %e\n", FLT_MIN);
  printf("Value of DOUBLE min %e\n", DBL_MIN);
  printf("Value of DOUBLE max %e\n", DBL_MAX);
  printf("Value of LONG DOUBLE min %Le\n", LDBL_MIN);
  printf("Value of LONG DOUBLE max %Le\n", LDBL_MAX);

  printf("Size of FLOAT %ld\n", sizeof(float));
  printf("Size of DOUBLE %ld\n", sizeof(double));
  printf("Size of LONG DOUBLE %ld\n", sizeof(long double));

// watch out with the format (also compile warnings) ! 

  printf("Value of FLOAT Max %d\n", FLT_MAX);
  printf("Value of FLOAT Min %d\n", FLT_MIN);
  printf("Value of DOUBLE min %d\n", DBL_MIN);
  printf("Value of DOUBLE max %d\n", DBL_MAX);
  printf("Value of LONG DOUBLE min %d\n", LDBL_MIN);
  printf("Value of LONG DOUBLE max %d\n", LDBL_MAX);
}
