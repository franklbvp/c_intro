/*
   char_int_xy.c
   taken from http://www.tech.dmu.ac.uk/~drs/ctec1401/A3.html
*/
#include <stdio.h>

int main()
{
    int x = 'A';
    int y;
    printf("x as a char: %c\tand as an int: %i\n", x, x);
    y = x + 1;
    printf("y as a char: %c\tand as an int: %i\n", y, y);
    return 0;
}
