/* demo_uint.c */

#include <stdio.h>


int main()
{
unsigned int value = 25;


printf("value %d \n", value);

value = value - 35;
printf("value %d \n", value);

value = value + 100;
printf("value %d \n", value);

// now with the u-placeholder instead of d

value = 25;

value = value - 35;
printf("value %u \n", value);

value = value + 100;
printf("value %u \n", value);


return 0;
}

