/* 
   change_const.c 
*/

#include <stdio.h>

void main ()
{

const double pi=3.1415;
double x;

x = pi * 2.0 * 2.0;

printf(" resultaat = %g", x);

pi = pi *2.0;

printf(" update pi = %g", pi);
}
