/* 
taken from Gribble C Bootcamp 
*/

#include <stdio.h>
int main() {
        int a = 2;
        double b = 3.5;
        double c = a * b;
        double d = a / b;
        int e = a * b;
        int f = a / b;
        printf("a=%d, b=%.3f, c=%.3f, d=%.3f, e=%d, f=%d\n",
                a, b, c, d, e, f);
        return 0;
}

