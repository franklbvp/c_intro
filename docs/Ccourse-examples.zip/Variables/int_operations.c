
/*
int_operations.c

use the lm option to link the math library

gcc int_operations.c -lm -o int_operations
(tell gcc to link your code against the math lib. Just be sure to put the flag after the objects you want to link)
*/

#include <stdio.h>
#include <math.h>

int main ()
{
  int a, b, c, d, e, f, g, r;

  a = 9;
  b = 4;
  printf("value of a = %d \n", a);
  printf("value of b = %d \n", b);

  c = a - b;
  printf("value of c (a-b) = %d \n", c);

  d = a + b;
  printf("value of d (a+b) = %d \n", d);

  e = a * b;
  printf("value of e (a*b) = %d \n", e);

  f = a / b;
  printf("value of f (a/b) = %d \n", f);

  r = a % b;
  printf("value of r (a %% b) = %d \n", r);

  g = pow(a,b);
  printf("value of g (a^b)= %d \n", g);

  return 0;
}
