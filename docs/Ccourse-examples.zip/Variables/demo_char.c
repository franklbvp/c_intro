/* demo_char.c */

/* characters can be treated as integers */

#include <stdio.h>

int main (void) 
{
  char c = 'a';
  
  while (c <= 'z')
  {
     printf("%d - %c \n", c, c);
     c = c + 1;
  
  }
  printf("size of c:  %lu \n", sizeof(c));
  
  return 0;
}

