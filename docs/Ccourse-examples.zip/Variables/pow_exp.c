#include<stdio.h>
#include<math.h>

// http://www.c4learn.com/c-programming/c-reference/pow-function/
// gcc pow_exp.c -lm


int main()
{
    int num,power,result;

    printf("\nEnter the number and its Power : ");
    scanf("%d%d",&num,&power);

    result = pow(num,power);
    printf("\nResult : %d \n",result);

    return(0);
}
