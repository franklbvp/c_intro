#include <stdio.h>

/* enum.c
http://cs.smith.edu/~thiebaut/classes/C_Tutor/node72.html
 */


int main(void)
{
enum Result_list {win,tie,bye,lose,no_show};
enum Result_list result;
enum Days_list {mon,tues,wed,thur,fri,sat,sun};
enum Days_list days;

   result = win;
   printf("    win = %d\n",result);
   result = lose;
   printf("   lose = %d\n",result);
   result = tie;
   printf("    tie = %d\n",result);
   result = bye;
   printf("    bye = %d\n",result);
   result = no_show;
   printf("no show = %d\n\n",result);

   for(days = mon;days < fri;days++)
      printf("The day code is %d\n",days);
}