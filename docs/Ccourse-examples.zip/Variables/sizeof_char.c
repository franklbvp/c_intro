/*
   taken from http://stackoverflow.com/questions/2172943/size-of-character-a-in-c-c
*/
#include <stdio.h>
int main(){
  char a = 'a';
  printf("Size of char : %d\n",sizeof(a));
  printf("Size of char : %d\n",sizeof(char));
  return 0;
 }
