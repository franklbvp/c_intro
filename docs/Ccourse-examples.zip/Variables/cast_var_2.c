#include <stdio.h>

/*
taken from https://portal.tacc.utexas.edu/-/c-programming-basics

Note
- double to int causes removal of the fractional part
- int to double conversion happened implicitly
*/


int main(){
double varA;
int varB = 2;
double varC = 9.34;
varA = varB;
varB = varC;
printf("varA: %lf, varB: %d, varC: %lf \n",varA, varB, varC);

char varD;
varA = 65.5;
varD = (char) varA;
printf("varA: %lf, varD: %c \n",varA, varD);

return 0;
}
