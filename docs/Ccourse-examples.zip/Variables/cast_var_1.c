#include <stdio.h>


/*
taken from https://portal.tacc.utexas.edu/-/c-programming-basics
*/


int main(){
double varA = 65.00;
char varB;
varB = (char) varA;
printf("varA: %lf, varB: %c",varA, varB);
return 0;
}
