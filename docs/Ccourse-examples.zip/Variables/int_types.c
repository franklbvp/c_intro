/* int_types.c  										 */
/* different types are shown, together with their limits */
/* Information about all types can be found in macros defined in the header <limits.h>.*/
/* <limits.h> holds various properties of the integer type representations */
/* Try compiling it with gcc -std=c99 */



#include <stdio.h>
#include <limits.h>

int main (void)

{
/* The maximum value for a char is CHAR_MAX, and the minimum CHAR_MIN, */
/* for signed char SCHAR_MAX and SCHAR_MIN */
/* and the maximum unsigned char is UCHAR_MAX (the minimum unsigned anything is always 0.)... */

  printf("Value of Char Max %d\n", CHAR_MAX);
  printf("Value of Char Min %d\n", CHAR_MIN);
  printf("Value of int min %d\n", INT_MIN);
  printf("Value of int max %d\n", INT_MAX);
  printf("Value of long min %ld\n", LONG_MIN);
  printf("Value of long max %ld\n", LONG_MAX);
  printf("Value of long long min %lld\n", LLONG_MIN);
  printf("Value of long long max %lld\n", LLONG_MAX);
  printf("Value of short min %d\n", SHRT_MIN);
  printf("Value of short max %d\n", SHRT_MAX);
  printf("Value of unsigned char max %d\n", UCHAR_MAX);
  printf("Value of unsigned int max %u\n", UINT_MAX);
  printf("Value of unsigned long max %lu\n", ULONG_MAX);
  printf("Value of unsigned int max %d\n", UINT_MAX);  // be careful with format specifier
 
  printf("Size of char %ld\n", sizeof(char));
  printf("Size of short %ld\n", sizeof(short));
  printf("Size of int %ld\n", sizeof(int));
  printf("Size of long %ld\n", sizeof(long));
  printf("Size of long long %ld\n", sizeof(long long));
}
