#include<stdio.h>
#include<time.h>
#include <stdlib.h>

/* 
rand returns a value between(inclusive) 0 and and RAND_MAX (defined by the compiler, often 32767). 
To get a more managable number, use the % operator, which returns the remainder of division.
*/

int main ()
	{
		int a, b, c;
		/* initialize random seed: */
		srand ( time(NULL) );
		/* Generate  random number: */
		a = rand() % 10 + 1;
                b = rand() % 10 + 1;
                /* calculate the sum */
		c = a + b; 
                printf("sum = %d \n", c);

		return 0;
	}

