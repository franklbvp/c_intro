/* segFault_demo.c
	program with a segfault
	to be used with gdb

if core is not dumped, try
 ulimit -c unlimited

gdb binary-file core-file

use backtrace bt command
*/

#include <stdio.h>
#include <stdlib.h>

int main(void) {
/* Illegal memory access if value of n is 
       not in the range 0, 1, ... 999 */
  int n,i;
  int foo[1000];
  n = 1500;
  for (i = 0; i < n ; i++) 
    foo[i] = i;

  return 0;
}
