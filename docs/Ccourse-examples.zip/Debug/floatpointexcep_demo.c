/*
based on 
http://cseweb.ucsd.edu/classes/fa09/cse141/tutorial_gcc_gdb.html

*/
#include <stdio.h>

int main()
{
  int a, b, i;
  float c;
  c = a/b;
  printf("%d/%d = %f\n",a,b,c);
  return 0;
}