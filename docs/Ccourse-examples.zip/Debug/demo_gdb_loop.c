#include <stdio.h>

int
main ()
{
  int i;
  /* The loop goes while i < 10, and i increases by one at each loop */
  for (i = 0; i < 10; i++)
    {
      printf ("%d\n", i);
    }
  return 0;
}
