/* add.c  
   Adds two integers and prints the result 
 
 source: https://www.fayewilliams.com/2011/02/01/command-line-gdb-tutorial-and-walkthrough-part-1/
 */
 
#include <stdio.h>
 
int Add(int i, int j);
 
int main()
{
    int i = 200;
    int j = 800;
    printf("Sum of %d and %d is %d\n", i, j, Add(i, j));
    return 0;
}
 
int Add(int i, int j)
{
    return i * j;
}