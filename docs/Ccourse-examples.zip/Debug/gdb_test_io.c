/*
test io in gdb
*/
#include <stdio.h>
   
   int main(void) {
       char buffer[100];
       fgets(buffer, 100, stdin);
       printf("You entered: %s", buffer);
       return 0;
   }