#include <stdio.h>  

/*
Demo generating a segmentation fault

compile with -g option


source: http://kb.iu.edu/data/aqsy.html

remark: it is possible that a core dump is not generated; solve this with
ulimit -c unlimited

*/

int main () 
{ 
int foo[5], n; 
memset((char *)0x0, 1, 100); 


printf (" Initial value of n is %d \n", n); 
return 0; 
}
