# include <stdio.h>

/*
Demo program to debug some code

compile with -g option

source: www.thegeekstuff.com/2010/03/debug-c-program-using-gdb/

*/

int main()
{
	int i, num, j;
//	printf ("Enter the number: ");
//	scanf ("%d", &num );
	num = 4;
	
	for (i=1; i<num; i++)
		j=j*i;    

	printf("The factorial of %d is %d\n",num,j);
}

