/* 
# invader.c 
# Print a pattern to the terminal using a predefined area 
# of 44 characters width and 16 lines height 
# The template defines the pattern with a series of pairs: 
# the first is the position in the current line that should 
# be filled in, the second is how many characters should be filled. 

source: https://www.fayewilliams.com/2011/02/01/command-line-gdb-tutorial-and-walkthrough-part-2/
*/
 
#include <stdio.h>  
#include <string.h> 
 
#define BUF_LEN 45  /*44 plus null terminator*/ 
#define TEMPLATE_LEN 37 
 
int template[TEMPLATE_LEN] = 
{ 8,4,32,4,12,4,28,4,8,28,4,8,16,12,32,8,0,44, 
0,4,8,28,40,4,0,4,8,4,32,4,40,4,12,8,24,8,0 }; 
 
int main() 
{ 
    unsigned int count = 0; 
    char buffer[BUF_LEN]; 
 
    memset(buffer, ' ', BUF_LEN); 
    buffer[BUF_LEN-1] = 0x00; 
 
    printf("\n\n"); 
    for (count = 0 ; count < TEMPLATE_LEN-1; count+=2) 
    { 
        int pos = template[count]; 
        int len = template[count]+1;                 
 
        int i = 0;
        for (i = 0 ; i < len ; ++i, ++pos)
        {
            buffer[pos] = '@';
        }
 
        /*check for end of row*/
        if (template[count] >= template[count+2])
        {
            /*print and reset*/
            printf("  %s\n  %s\n", buffer, buffer);
            memset(buffer, ' ', BUF_LEN);
            buffer[BUF_LEN-1] = 0x00;
 //           count = 0;
        }
    }
    printf("\n\n"); 
 
    return 0; 
}