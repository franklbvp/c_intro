/*
Demo generating a segmentation fault

compile with -g option


source: www.cprogramming.com/debugging/segfaults.html


remark: it is possible that a core dump is not generated; solve this with
ulimit -c unlimited

*/

void foo();
       
int main()
{
foo();
return 0;
}

void foo()
{
char *x = 0;  // the pointer is set to null
*x = 3;
}

