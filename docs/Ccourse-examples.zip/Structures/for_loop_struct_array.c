#include <stdio.h>
#include <string.h>
/* 
loop over a list of colors, the colors are stored in a structure
 */


void display(char *name);

/************************************************************************/

int main ()
   {
   struct record { char color[20];};
   struct record a[5];
   int i, ll;
   
   strcpy(a[0].color, "yellow");
   strcpy(a[1].color, "blue");
   strcpy(a[2].color, "black");
   strcpy(a[3].color, "white");
   strcpy(a[4].color, "cyan");

   ll = sizeof(a) / sizeof(a[0]);
   
   for (i = 0; i <= ll-1; i++){
       display(a[i].color);
   }
   return 0; 
   }
/************************************************************************/

void display(char *name)
   {
   printf("color is %s \n", name);
   }

