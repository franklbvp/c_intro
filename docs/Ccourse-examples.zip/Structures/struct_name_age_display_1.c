/* 
 * Date 13-Jun-94
 *
 * 	Pass 'struct' elements to a function.
 */
#include <stdio.h>

void display(char *name, int age);

/************************************************************************/

main ()
   {
   struct record { char name[20]; int age;} a;

   strcpy(a.name, "Joe Brown");
   a.age = 21;

   display (a.name, a.age);
   }

/************************************************************************/

void display(char *name, int age)
   {
   printf("name is %s \nage is %d \n", name, age);
   }
