/* 
struct_point_xy.c
 */
#include <stdio.h>

struct  point
{
   int x = 0;
   int y = 100;
};

struct point x1;
struct point x2 = {200, 300};

void pointinfo(struct point xx);

int main()
{
   printf ("x1 without initialisation \n");
   pointinfo (x1);

   x1.x = 100;
   x1.y = 100;
      
   printf ("x1 after initialisation \n");
   pointinfo (x1);

   printf ("x2 after initialisation \n");
   pointinfo (x2);

   x1.x += x2.x;
   printf ("x1  summing x-dim of x2 \n");
   pointinfo (x1);
   
   return 0;
}

void pointinfo ( struct point xx )
{
    printf ("dim1 %d \t dim2 %d \n", xx.x, xx.y);
}

