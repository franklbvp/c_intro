/* 
 * 	Pass 'struct' elements to a function.
 */
#include <stdio.h>
#include <string.h>

struct record { char name[20]; int age;};

void display(struct record);

/************************************************************************/

int main ()
   {
   struct record a;

   strcpy(a.name, "Joe Brown");
   a.age = 21;

   display (a);
   return 0; 
  }

/************************************************************************/

void display(struct record a)
   {
   printf("name is %s \t age is %d \n", a.name, a.age);
   }
