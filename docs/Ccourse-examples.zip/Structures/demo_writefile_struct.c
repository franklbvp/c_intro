#include <stdio.h>

/* random record description - could be anything */
struct rec
{
    int x,y,z;
};

/* writes and then reads 10 arbitrary records from the file "junk". */
void main()
{
    int i,j;
    FILE *f;
    struct rec r;

    /* create the file of 10 records */
    f=fopen("junk","w");
    for (i=1;i<=10; i++)
    {
        r.x=i;
        r.y=i*2;
        r.z=i*3;
        fwrite(&r,sizeof(struct rec),1,f);
    }
    fclose(f);

}