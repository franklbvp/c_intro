#include <stdio.h>

   /*************************************************************************/

   struct x {int a; int b; int c;} ;	/* Declare the structure.	    */

   void function(struct x * );		/* Declare the function.	    */

   /*************************************************************************/

   main() 
   {  
					/* Declare two variables.
					 * z == type struct x
					 * pz == a pointer to type struct x
					 */
     struct x z, *pz; 			

     pz = &z;        			/* put the address of 'z' into 'pz' */
     z.a = 10;				/* initialize z.a		    */
     z.a++;				/* Increment z.a		    */

					/* print the contents of 'z.a'
					 * using the pointer 'pz'	    */
   
     printf(" first member before the function call %d \n", pz->a);

					/* Call 'function' passing the 
					 * pointer 'pz'			    */
     function(pz);  			

					/* Print the NEW value of 'z.a'
					 * using three different notations  */
     printf(" first member after the function call %d \n", pz->a);
     printf(" first member after the function call %d \n", (*pz).a);
     printf(" first member after the function call %d \n", z.a);

   }

   /*************************************************************************/
   
   void function(struct x * pz)
   { 
					/* Print the value of 'z.a' by
					 * referencing the pointer 'pz'
					 * which holds the address of 'z'   */
     printf(" first member inside the function %d \n", pz->a);
      
					/* Increment the value of 'z.a'
					 * this is the source location
					 * in memory.			    */
     pz->a++;
     
   }

   /*************************************************************************/
  

