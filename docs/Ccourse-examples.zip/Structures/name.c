#include <stdio.h>

#define BUFFER_SIZE 100
#define NELEMS(x)   (sizeof(x)/sizeof(x[0]))

struct Personnel {
    char name[BUFFER_SIZE];
    int age;
    double height;
};

void get_details(struct Personnel *person)
{
    printf("Enter person's details (name, age, height): ");
    scanf("%s %d %lf", person->name, &person->age, &person->height);
}

//void print_details( struct Personnel *person)
void print_details(const struct Personnel *person)
{
    printf("Name: %s\nAge: %d\nHeight: %f\n\n", person->name, person->age, person->height);
//    person->age = person->age + 6;  // check with - without const
}

int main(void)
{
    struct Personnel me = { "Fred", 21, 1.83 };
    struct Personnel them[3] = { { "Nobody", 0, 0 }, { "Mary", 19, 1.50 } };
    int i;

    for (i = 2; i < NELEMS(them); ++i)
        get_details(them + i); 

    print_details(&me);

    for (i = 0; i < NELEMS(them); ++i)
        print_details(&them[i]);

    printf(" second round of printing \n");
    for (i = 0; i < NELEMS(them); ++i)
        print_details(&them[i]);

    return 0;
}
