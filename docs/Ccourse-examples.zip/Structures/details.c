#include <stdio.h>
#include <string.h> /* strcpy */

struct Personnel {
    char name[100];
    int age;
    double height;
};

struct Personnel morph_details(struct Personnel person)
{
    strcpy(person.name, "Mary");
    person.age = 25;
    person.height = 1.65;
    return person;
}

void print_details(struct Personnel person)
{
    printf("Name: %s\nAge: %d\nHeight: %f\n\n", person.name, person.age, person.height);
}

int main(void)
{
    struct Personnel before = { "Fred", 21, 1.83 };
    struct Personnel after;

    after = morph_details(before);

    print_details(before);
    print_details(after);

    return 0;
}
