#include <stdio.h>
// demo_llist_1.c
struct list 
{
  int         numb;
  struct list *next;
};

void main()
{
                struct list n1, n2, n3, *pll;
                int          i, j;

                pll = &n1;
		printf(" pointer to n1 %p \n", pll);
                n1.numb = 100;
                n2.numb = 200;
                n3.numb = 300;
                n1.next = &n2;
                n2.next = &n3;
                i = n1.next->numb;
		j = n1.numb;
		
                printf("n2.next->numb= %d \n", n2.next->numb);
                printf("i(n1.next->numb)= %d \n", i);
                printf("j (n1.numb)= %d \n", j);
                printf("*pll->numb= %d \n", pll->numb);
}
