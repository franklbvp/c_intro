/* struct_point_1.c 

compile with -lm!
*/

#include <stdio.h>
#include <math.h>

int main() {

float d;

struct point{
  float x;
  float y;
};

typedef struct point point_struct;

point_struct a, b;

printf("The coordinates of the point a are: ");
scanf("%f %f",&a.x,&a.y);

printf("\nThe coordinates of the point b are: ");
scanf("%f %f",&b.x,&b.y);

d = sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
printf("\nThe distance between a and b is %f\n",d);

return 0;
}
