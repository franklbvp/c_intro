/************************************************************************
 *
 * Purpose: Demonstrate structures.
 * Author:  M.J. Leslie.
 * Date:    13-June-94
 *
 *
 ************************************************************************/

#include <stdio.h>
#include <string.h>

int main ()
   {
					/* Declare the structure.	*/
   struct record { char name[20]; int age;} a ;

					/* Put some values into the
					 * structure.			*/
   strcpy(a.name, "Joe Brown");
   a.age = 21;

					/* Display the contents of the
					 * structure.			*/

   printf("name is %s \nage is %d \n", a.name, a.age);
 
   return 0;
  }

