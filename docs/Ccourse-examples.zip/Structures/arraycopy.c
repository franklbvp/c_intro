#include <stdio.h>

#define NELEMS(x)   (sizeof(x)/sizeof(x[0]))

struct Array {
    double x[10];
};

int main(void)
{
    struct Array x = { { 1, 2, 3, 4, 5 } };
    struct Array y;
    int i;

    y = x;

    for (i = 0; i < NELEMS(y.x); ++i)
        printf("%.3f ", y.x[i]);

    return 0;
}
