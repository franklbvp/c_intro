/* manip_struct.c */
#include <stdio.h>

typedef struct {
		int p1;
	    int p2;} couple;

couple create_couple(int, int);
void print_couple(couple);

int main()
{
	couple res1={1,1};
	couple res2={1,2};
    couple res3, res4;

// assign a struct
    res3 = res2;

// create couple
    res4 = create_couple(4, 7);
	
// print couple
    print_couple(res1);
    print_couple(res2);
    print_couple(res3);
    print_couple(res4);
	
// compare?
/*
    if (res1 == res3) {
		printf("res1 and res3 are equal");
	}
*/	
    return	0;
}
couple create_couple(int i, int j)
{
    couple val;
	val.p1 = i;
	val.p2 = j;
	
	return val;
}

void print_couple(couple cc)
{
    printf("couple p1: %d - couple p2: %d \n", cc.p1, cc.p2);
}
