/* 
struct_manip_1.c
 manipulate the data contained in a strucure
 */
#include <stdio.h>
#include <string.h>

typedef struct record 
   { char name[20]; int age; float reward;} Person;
   
void display(char *name, int age, float reward);
void raise(Person * a);

int main ()
   {
   Person p1, p2;

   strcpy(p1.name, "Joe Brown");
   p1.age = 21;
   p1.reward = 123.4;
   display (p1.name, p1.age, p1.reward);
   raise(&p1);
   display (p1.name, p1.age, p1.reward);
   
   return 0;
   }


void display(char *name, int age, float reward)
   {
   printf("name is %s \nage is %d \nreward is %lf \n", name, age, reward);
   }

void raise(Person * a)
   {
   a->reward = a->reward * 1.15;
   }
