/* demo_swap_struct.c */
#include <stdio.h>

typedef struct {
		int p1;
	    int p2;} couple;

couple swap(int i, int j);

void main()
{
    int a,b;
    a=5;
    b=10;
	
	couple res;
	
	printf("a=%d, b=%d  -before swap-\n",a,b);
    res = swap(a,b);
	a = res.p1;
	b = res.p2;
    printf("a=%d, b=%d  -after swap-\n",a,b);
}
couple swap(int i, int j)
{
    couple val;
	val.p1 = j;
	val.p2 = i;
	
	return val;
}
