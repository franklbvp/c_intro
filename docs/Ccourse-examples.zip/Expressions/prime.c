#include <stdio.h>

/* Determine whether or not a number is prime. 
 * Note, 1 is not prime by definition. */
int main(void)
{
    const int MIN_number = 2;
    const int MAX_number = 50;
    enum {FALSE, TRUE};

    int val, isprime=TRUE, i;

    /* Get user input */
    printf("Enter a number between %d and %d: ", MIN_number, MAX_number);
    scanf ("%d", &val);
    if (val < MIN_number || val > MAX_number) {
        printf("Error: invalid range!!\n");
        return -1;
    }

    /* Brute-force algorithm to check for primeness */
    i = MIN_number;
    while(i < val) { 
        if (val % i == 0)
            isprime = FALSE;
        i = i + 1;
    }
    
    /* Display result */
    if (isprime == TRUE) 
        printf("The value %d is prime.\n", val);
    else
        printf("The value %d is not prime.\n", val);
} 
