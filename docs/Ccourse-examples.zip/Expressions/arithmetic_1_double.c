#include <stdio.h>

/*
   arthmetic_1_double.c
*/

int main ()
{
  double var1 = 10;
  double var2 = 2;
  double var3 = 35;
  double var4 = 8;
  double result;

  result = var1 + var2;

  printf ("Sum of var1 and var2 is %f\n", result);
  result = var3 * var3;
  printf ("Square of var3 is %f\n", result);
  result = var2 + var3 * var4;	/* precedence */
  printf ("var2 + var3 * var4 =%f\n", result);
/*  result = var3 % var1;
  printf ("var3 %% var1 is %d\n", result);
*/
  return 0;

}
