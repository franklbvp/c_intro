#include <stdio.h>

/*
leapyear.c
Determine whether year is a leap-year 
*/
int main(void)
{
    const int MIN_YEAR = 1828;
    const int MAX_YEAR = 3003;
    int year;

    printf("Enter a year between %d and %d: ", MIN_YEAR, MAX_YEAR);
    scanf("%d", &year);
    if (year < MIN_YEAR || year > MAX_YEAR) {
        printf("Error: invalid year!!\n");
        return -1;
    }

    /* A leap year must be divisible by 4 but not by 100, except
     * that years divisible by 400 are leap years */
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        printf("The year %d is a leapyear.\n", year);
    else
        printf("The year %d is not a leapyear.\n", year);
} 
