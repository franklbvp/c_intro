#include <stdio.h>

/*
   arthmetic_1.c
*/

int main ()
{
  int var1 = 10;
  int var2 = 2;
  int var3 = 35;
  int var4 = 8;
  int result;

  result = var1 + var2;

  printf ("Sum of var1 and var2 is %d\n", result);
  result = var3 * var3;
  printf ("Square of var3 is %d\n", result);
  result = var2 + var3 * var4;	/* precedence */
  printf ("var2 + var3 * var4 =%d\n", result);
  result = var3 % var1;
  printf ("var3 %% var1 is %d\n", result);

  return 0;

}
