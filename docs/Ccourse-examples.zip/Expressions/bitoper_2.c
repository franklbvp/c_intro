/*
bitoper_2.c
taken from https://www.programiz.com/c-programming/bitwise-operators

12 = 00001100 (In Binary)
25 = 00011001 (In Binary)

*/

#include <stdio.h>
int main(void)
{
    int a = 12, b = 25;

    printf("Output = %d \n", a&b);
    printf("Output = %d \n", a|b);	
    printf("Output = %d \n", a^b);
 	  printf("\n");
	
    int num=210, i;
    for (i=0; i<=2; ++i)
        printf("Right shift by %d: %d\n", i, num>>i);

    printf("\n");

    for (i=0; i<=2; ++i) 
        printf("Left shift by %d: %d\n", i, num<<i);    
	
    return 0;
}