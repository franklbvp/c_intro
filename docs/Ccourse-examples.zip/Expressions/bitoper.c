#include <stdio.h>

int main (void)
{
  int i1, i2;
  int n1, n2, n3;
  
  i1 = 2;   /* binary: 010 */
  i2 = 4;   /* binary: 100 */

  if (i1 && i2) printf (" both && not 0 \n");
  if (i1 & i2) printf (" both & not 0 \n");
  
  n1 = 5;    /* binary: 0101 */
  n1 = n1 & 0177;    /* bit operation with octal 177 = 1 111 111 */
  printf(" result n1 & 0177   %d \n", n1);
  n1 = n1 & 0166;    /* bit operation with octal 166 = 1 110 110 */
  printf(" result n1 & 0166   %d \n", n1);
  n1 = n1 & 166;    /* bit operation with 166 = 10100110 */
  printf(" result n1 & 166   %d \n", n1);

  n2 = 5;
  n2 = n2 | 0177;    /* bit operation with octal 177 = 1 111 111 */
  printf(" result n2 | 0177   %d \n", n2);

  n2 = 5;
  n2 = n2 | 0166;    /* bit operation with octal 166 = 1 110 110 */
  printf(" result n2 | 0166   %d \n", n2);

  n3 = 7;
  n3 = n3 << 2;    // multiply with power of 2
  printf(" result n3 << 2   %d \n", n3);
  
  n3 = 7;
  n3 = n3 << 5;
  printf(" result n3 << 5   %d \n", n3);
  
  n3 = 7;  /* binary: 0111 */
  n3 = n3 >> 2;    // divide
  printf(" result n3 >> 2   %d \n", n3);
  
  n3 = ~i1;
  printf(" result ~i1   %d \n", n3);
  
  n3 = !i1;
  printf(" result !i1   %d \n", n3);

  n3 = ~i2;
  printf(" result ~i2   %d \n", n3);
  
  return 0;

}

