/* 
increment.c

Usage of pre-fixing and post-fixing the increment operator 
*/ 

#include <stdio.h> 

void main()

{

    int x = 10;

    printf("Value of x after pre-fixing ++ is %d\n", ++x);

    printf("Value of x after post-fixing ++ is %d\n",x++);
    
    printf("be careful \n");
    printf("What is this - x: %d  - x++ : %d  - ++x: %d \n",x, x++, ++x);
    

}

















