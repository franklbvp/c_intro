#include <stdio.h>

int
main (void)
{
  int varA, x;			/* Value is unspecified now */
// varA = 10; /* value is set to 10 */
  x = varA++;			/* value is 11 */
  printf ("value x is %d\n", x);
  varA *= 2;			/* value is 22 */
  printf ("value varA is %d\n", varA);
  return 0;
}
