#include <stdio.h>
/* 
factorial.c
Calculate the factorial of a non-negative integer.
Result = n*(n-1)*(n-2)* ... *2*1 
Note, the factorial of 0 is 1. 
*/

int main(void)
{
    int result=1, n;

    /* Get user input */
    printf("Enter a non-negative integer value: ");
    scanf("%d", &n);
    if (n < 0) {
        printf("Error: number must be 0 or greater!!\n");
        return -1;
    }

    /* Calculate factorial */
    while (n)
        result *= n--;

    printf("The factorial is %d\n", result);
} 
