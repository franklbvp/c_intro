#include <stdio.h>
#include <math.h>
/* http://www.tutorialspoint.com/c_standard_library/c_function_sprintf.htm 
sprintf_1.c
compile gcc sprintf_1.c -lm
*/

int main()
{
   char str[80];

   sprintf(str, "Value of Pi = %f", M_PI);
   puts(str);
   
   return(0);
}
