/*
  based on www.cs.colstate.edu/~cs156
*/


#include <stdio.h>
#include <stdlib.h>

int main(){
   char first[100], last[100];

   printf("Enter your first name: ");
   fgets(first, sizeof(first), stdin);

   printf("Enter your last name: ");
   fgets(last, sizeof(last), stdin);

   printf("\n Your name is: %s %s", first, last);

   return 0;

}
