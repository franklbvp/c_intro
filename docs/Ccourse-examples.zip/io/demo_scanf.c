#include <stdio.h>
/* 
demo_scanf.c
enter data separated by blancs */

int main()
{
  int code; 
  int age;
  char codex;
  float weight; 
  
  printf("Enter age, codex , weight \n");
  
  code=scanf("%d %c %f", &age, &codex, &weight);

  printf("number of arguments read = %d \n", code);
  printf(" age is %d, codex is %c, weight is %5.1f \n", age,
  codex, weight);

 return 0;
}
