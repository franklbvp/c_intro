/*

Read all characters from a file, only the b's are put on outpu

based on
http://beej.us/guide/bgc/output/html/multipage/getc.html
*/


#include <stdio.h>

int main(void)
{
    FILE *fp;
    int c;

// getc
    fp = fopen("datafile.txt", "r"); // error check this!

    // this while-statement assigns into c, and then checks against EOF:

    while((c = getc(fp)) != EOF) {
        if (c == 'b') {
            putchar(c);
        }
    }
    putchar('\n');
    fclose(fp);

//fgetc

   fp = fopen("datafile2.txt", "r"); // error check this!

    // this while-statement assigns into c, and then checks against EOF:

    while((c = fgetc(fp)) != EOF) {
        if (c == 'b') {
            putchar(c);
        }
    }
    putchar('\n');
    fclose(fp);

// getchar

   printf("Enter character: ");
   c = getchar();
 
   printf("Character entered: ");
   putchar(c);
  putchar('\n');


    return 0;
}
