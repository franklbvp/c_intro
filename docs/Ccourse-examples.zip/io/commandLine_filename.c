/*

 get file name from command line

usage: commandLine_filename  temp3city.txt
*/

#include<stdio.h>

int main(int argc, char *argv[]) {

  double temp3c[50][3];
  double tmax = -100;
  int i;
  FILE *fp;

   printf("No. of arguments : %d\n", argc);


// reading file
  fp = fopen(argv[1], "r");
  if (fp == NULL) {
    printf("sorry can't open temp3city.txt\n");
    return 1;
  }
  else {
    for (i=0; i<31; i++) {
     fscanf(fp, "%lf %lf %lf\n", &temp3c[i][1], &temp3c[i][2], &temp3c[i][3]);
     if (tmax < temp3c[i][1]) {
        tmax = temp3c[i][1];
     }
     if (tmax < temp3c[i][2]) {
        tmax = temp3c[i][2];
     }
     if (tmax < temp3c[i][3]) {
        tmax = temp3c[i][3];
     }
    }
    fclose(fp);
    for (i=0; i<31; i++) {
     printf("%d %5.2f %5.2f %5.2f\n", i, temp3c[i][1], temp3c[i][2], temp3c[i][3]);
     }
    printf("\n\n maximum temperature = %5.2f \n", tmax);
  }

}
