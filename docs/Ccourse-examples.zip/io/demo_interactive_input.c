#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isQuit(char str[]);
int main(void) {
    for (;;) {
        char str[80];
        scanf("%s", str);
        if (isQuit(str))
            break;
        printf("hello %s!\n", str);
    }
    return 0;
}
int isQuit(char str[]){
int ival;
ival = strcmp(str, "quit");
if (ival == 0)
	return 1;
else
	return 0;
}