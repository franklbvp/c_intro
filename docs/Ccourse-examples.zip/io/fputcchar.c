/*

Write a single character to the console or to a file

based on
https://www.tutorialspoint.com/c_standard_library/c_function_putc.htm

*/

#include <stdio.h>

int main ()
{
   FILE *fp1, *fp2;
   int ch; 

// putc
   fp1 = fopen("file1.txt", "w");
   for( ch = 33 ; ch <= 100; ch++ ) 
   {
      putc(ch, fp1);
   }
   fclose(fp1);
   
// fputc does the same as putc, only different implementation
   fp2 = fopen("file2.txt", "w");
   for( ch = 33 ; ch <= 100; ch++ ) 
   {
      fputc(ch, fp2);
   }
   fclose(fp2);
 
// putchar writes the character to the screen, same as putc(c, stdout)

   for (ch = 'A'; ch <= 'Z'; ch++)
   {
       putchar(ch);
   }
   putchar('\n');

   return 0;
}
