#include <stdio.h>

/*
demo_scanf_fgets.c

https://www.thecrazyprogrammer.com/2021/05/fgets-vs-scanf.html

Check with the input:
3
10.23
Welcome to The Crazy Programmer

*/
 
int main(){
int a ;
int ret;
float b ;
char c[100] ;
char buf[100] ;


scanf ("%d" , &a);
scanf ("%f" , &b);
scanf ("%s" , c);
printf("%d" , a);
printf("\n");
printf("%f" , b);
printf("\n");
printf("%s" , c);
printf("\n");

printf("use fgets \n");
if (fgets(buf, 100, stdin)){
ret = sscanf(buf, "%s", c);
printf("%s\n", c);
}
return 0 ;
}