#include <stdio.h>
#include <string.h>
/* 
sscanf_1.c
http://www.tutorialspoint.com/c_standard_library/c_function_sscanf.htm */

int main()
{
   int day, year;
   char weekday[20], month[20], dtm[100];

   strcpy( dtm, "Saturday March 25 1989" );
   printf("%s \n", dtm);

   sscanf( dtm, "%s %s %d  %d", weekday, month, &day, &year );
   printf("%s \n", dtm);

   printf("%s %d, %d = %s\n", month, day, year, weekday );
    
   return(0);
}
