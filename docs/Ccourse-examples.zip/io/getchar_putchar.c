#include <stdio.h>

/* http://www.tutorialspoint.com/cprogramming/c_input_output.htm */

int main( )
{
   int c;

   printf( "Enter a value :");
   c = getchar( );

   printf( "\nYou entered: ");
   putchar( c );

   return 0;
}