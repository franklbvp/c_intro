#include "stdio.h"
/* test different format specifiers 
format_specifier_1.c
 http://www-control.eng.cam.ac.uk/~pcr20/C_Manual/chap03.html
*/

int main()
{
 printf("/%d/\n",336);
 printf("/%2d/\n",336);
 printf("/%10d/\n",336);
 printf("/%-10d/\n",336);

 printf("/%f/\n",1234.56);
 printf("/%e/\n",1234.56);
 printf("/%4.f/\n",1234.56);
 printf("/%3.1f/\n",1234.56);
 printf("/%10.3f/\n",1234.56);
 printf("/%10.3e/\n",1234.56);
 printf("/%g/\n",1234.56);
 printf("/%g/\n",1234.5600008);
 printf("/%g/\n",12340000.56);

 return 0;
}
