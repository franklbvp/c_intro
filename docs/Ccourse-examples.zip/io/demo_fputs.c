/*
  based on tutorialspoint
*/


#include <stdio.h>
#include <stdlib.h>

int main(){
   FILE *fp;
   fp = fopen("filefputs.txt", "w+");
 
   fputs(" this is text from a C program", fp);
   fputs("use it on the screen", stdout);

   return 0;

}
