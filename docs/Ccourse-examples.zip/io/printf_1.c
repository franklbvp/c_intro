#include<stdio.h>

/* test printf */

void main()
{
 char name[30] = "I Am";

 printf("\nEnter your name: \n");
 printf("the sum of 5 and 6 = %d \n ", 5+6); 
 printf("\nHello %s \n",name);
}
