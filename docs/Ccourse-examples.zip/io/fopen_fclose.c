#include "stdio.h"

/* http://www.fcet.staffs.ac.uk/rgh1/ */ 
  int
main (void) 
{
  int a, b, c;
char filename[21];		// string file name 
FILE *out_file;		// file pointer for output 

printf ("\ntype name of output file: "); // prompt on screen
gets (filename);		// input from keyboard
  out_file = fopen (filename, "w"); // open file for output
    if (out_file == NULL)
    
    {
      printf ("\ncannot open: %s", filename);
      return 1;		//  abnormal program exit
    }
  printf ("\ntype 2 integers");	// prompt
scanf ("%d%d", &a, &b);	// from keyboard
c = a + b;
  fprintf (out_file, "%d\n", c);
  
// output to file
fclose (out_file);
  return 0;			// normal program exit
}


