#include <stdio.h>
// read_temp3city.c
int main()
{
   int numc1[31], numc2[31], numc3[31];
   int maxt[3] = {-999 -999 -999};
   int dayt[3] = {-999 -999 -999};
   int count;
   FILE *fptr;
   fptr = fopen("temp3city.txt","r");

   if(fptr == NULL){
      printf("Error!");   
      return 1;             
   }
   for(count = 0; count <= 30; ++count) {
      fscanf(fptr,"%d %d %d",&numc1[count],&numc2[count],&numc3[count]);}
   fclose(fptr);

// search  for the maximum at each city
   for (count = 0; count <= 30; ++count){
    if (numc1[count] > maxt[0]) {
       maxt[0]  = numc1[count];
	     dayt[0]  = count + 1;}}
  printf("Maximum temperature at day %d and it's value is %d.\n", dayt[0], maxt[0]);
  
   for (count = 0; count <= 30; ++count){
    if (numc2[count] > maxt[1]) {
       maxt[1]  = numc2[count];
	     dayt[1]  = count + 1;}}
  printf("Maximum temperature at day %d and it's value is %d.\n", dayt[1], maxt[1]);

   for (count = 0; count <= 30; ++count) {
    if (numc3[count] > maxt[2]) {
       maxt[2]  = numc3[count];
	     dayt[2]  = count + 1;}}
  printf("Maximum temperature at day %d and it's value is %d.\n", dayt[2], maxt[2]);
  return 0;
}
