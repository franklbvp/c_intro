/*

http://gribblelab.org/CBootcamp/10_Input_and_Output.html

*/

#include <stdio.h>

int main() {

  FILE *fp;
  double tmpC[11] = {-10.0, -8.0, -6.0,
                      -4.0, -2.0,  0.0,  2.0,
                       4.0,  6.0,  8.0, 10.0};
  double tmpF;
  double temp3c[50][3];
  double tmax = -100;
  int i;

// writing file
  fp = fopen("outfileTemp.txt", "w");
  if (fp == NULL) {
    printf("sorry can't open outfile.txt\n");
    return 1;
  }
  else {
    // print a table header
    fprintf(fp, "%10s %10s\n", "Celsius", "Fahrenheit");
    for (i=0; i<11; i++) {
      tmpF = ((tmpC[i] * (9.0/5.0)) + 32.0);
      fprintf(fp, "%10.2f %10.2f\n", tmpC[i], tmpF);
    }
    fclose(fp);
  }

// reading file
  fp = fopen("temp3city.txt", "r");
  if (fp == NULL) {
    printf("sorry can't open temp3city.txt\n");
    return 1;
  }
  else {
    for (i=0; i<31; i++) {
     fscanf(fp, "%lf %lf %lf\n", &temp3c[i][1], &temp3c[i][2], &temp3c[i][3]);
     if (tmax < temp3c[i][1]) {
        tmax = temp3c[i][1];
     }
     if (tmax < temp3c[i][2]) {
        tmax = temp3c[i][2];
     }
     if (tmax < temp3c[i][3]) {
        tmax = temp3c[i][3];
     }
    }
    fclose(fp);
    for (i=0; i<31; i++) {
     printf("%d %5.2f %5.2f %5.2f\n", i, temp3c[i][1], temp3c[i][2], temp3c[i][3]);
     }
    printf("\n\n maximum temperature = %5.2f \n", tmax);
  }

  return 0;
}

