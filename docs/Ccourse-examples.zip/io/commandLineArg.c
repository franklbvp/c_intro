/*
based on

compile it, run it ./a.out Hello World
*/

#include <stdio.h>

/* main
 * params : argc ( No. of command line arguments )
 * argv[] : array of strings ( arguments )
 */
int main(int argc, char *argv[]) {
   printf("No. of arguments : %d\n", argc);
   int i;
   for ( i = 0; i < argc; i++ ) {
      printf("argv[ %d ] : %s\n", i, argv[i]);
   }
   return 0;
}
