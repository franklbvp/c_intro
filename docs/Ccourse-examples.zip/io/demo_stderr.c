#include "stdio.h"
/*
demo_stderr.c
https://www.cs.bu.edu/teaching/c/file-io/intro/
*/

int
main (void) 
{
  
FILE *ifp;
FILE *ofp;
char *mode = "r";
char outputFilename[] = "out.list";

//ifp = fopen("in.list", mode);  // in.list does not exist
ifp = fopen("temp3city.txt", mode);  // temp3city.txt exist

if (ifp == NULL) {
  fprintf(stderr, "Can't open input file in.list!\n");
  return 1;
}

ofp = fopen(outputFilename, "w");

if (ofp == NULL) {
  fprintf(stderr, "Can't open output file %s!\n",
          outputFilename);
  return 1;
}
}
