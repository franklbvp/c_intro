#include <stdio.h>
#include <math.h>


int main()
{

   puts("This is the printed string, puts is automatically putting a new line");
   
   return 0;
}
