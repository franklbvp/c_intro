#include <stdio.h>
// demo_extern_main_2.c
extern int counter; /* loop counter */

extern void inc_counter(void);  /* increment counter */

int main()
{
  int index;
  
  for (index = 0; index < 10; index++)
      inc_counter();
  printf("counter is %d \n", counter);
  return 0;
}      
