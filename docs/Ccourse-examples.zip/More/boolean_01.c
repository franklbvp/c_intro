#include <stdio.h>  
#include<stdbool.h>  

/*
https://www.javatpoint.com/c-boolean
boolean_01.c
*/

int main()  
{  
bool b[2]={true,false}; // Boolean type array  
for(int i=0;i<2;i++) // for loop  
{  
printf("%d \n",b[i]); // printf statement  
}  
return 0;  
}  