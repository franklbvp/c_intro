#include <stdio.h>
/* check_return.c
echo $?
https://www.tutorialspoint.com/cprogramming/c_command_line_arguments.htm
This program expects 1 argument
*/
int main( int argc, char *argv[] )  {

   if( argc == 2 ) {
      printf("The argument supplied is %s\n", argv[1]);
      return 0;
   }
   else if( argc > 2 ) {
      printf("Too many arguments supplied.\n");
      return 2;
   }
   else {
      printf("One argument expected.\n");
      return 1;
   }
}
