#include <stdio.h>
#include <string.h>

/*
 union_03.c
 https://sceweb.sce.uhcl.edu/helm/WEBPAGE-C/my_files/TableContents/Module-18/module18page.html

 members of union are being used at a time 
*/
 
union Data {
   int i;
   float f;
   char str[20];
};
 
int main( ) {

   union Data data;        

   data.i = 10;
   printf( "data.i : %d\n", data.i);
   
   data.f = 220.5;
   printf( "data.f : %f\n", data.f);
   
   strcpy( data.str, "C Programming");
   printf( "data.str : %s\n", data.str);

   return 0;
}