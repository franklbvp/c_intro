// demo_extern_sub_2.c
int counter; 

void inc_counter(void)
{
   ++counter;
}
