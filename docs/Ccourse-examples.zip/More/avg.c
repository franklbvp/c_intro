int avg( int x, int y )
//avg.c
{
  int sum = x + y;
  return sum / 2;
}
