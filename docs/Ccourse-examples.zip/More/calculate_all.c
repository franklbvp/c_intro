#include <stdio.h>

/*
calculate_all.c

perform some calculations on 2 integer numbers

*/

int avg( int x, int y );
int largest( int x, int y);


int main()
{
  int a = 10;
  int b = 20;
  int r1, r2; 
  r1 = avg( a, b );
  r2 = largest( a, b);
  printf( "average of %d and %d is %d\n", a, b, r1 );
  printf( "largest of %d and %d is %d\n", a, b, r2 );
  return  0;
}

int avg( int x, int y )
{
  int sum = x + y;
  return sum / 2;
}

int largest( int x, int y )
{
  int large;
  if (x > y) {
  large = x;}
  else {
  large = y;}
  return large;
}
