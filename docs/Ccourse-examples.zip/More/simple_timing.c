/*
based on http://stackoverflow.com/questions/5248915/execution-time-of-c-program

he C library function clock_t clock(void) returns the number of clock ticks elapsed since the program was launched. To get the number of seconds used by the CPU, you will need to divide by CLOCKS_PER_SEC.

check also on command line with time ./a.out

*/
#include <stdio.h>
#include <time.h>


int main()
{
    clock_t tic = clock();

    printf(" this is a line printed \n \n \n");

    clock_t toc = clock();

    printf("Elapsed: %f seconds\n", (double)(toc - tic) / CLOCKS_PER_SEC);

    return 0;
}
