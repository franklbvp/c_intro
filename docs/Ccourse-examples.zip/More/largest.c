int largest( int x, int y )
// largest.c
{
  int large;
  if (x > y) {
  large = x;}
  else {
  large = y;}
  return large;
}
