#include <stdio.h>
/* command_line_argument_1.c
https://www.tutorialspoint.com/cprogramming/c_command_line_arguments.htm
This program expects 1 argument
*/
int main( int argc, char *argv[] )  {

   if( argc == 2 ) {
      printf("The argument supplied is %s\n", argv[1]);
   }
   else if( argc > 2 ) {
      printf("Too many arguments supplied.\n");
   }
   else {
      printf("One argument expected.\n");
   }
}
