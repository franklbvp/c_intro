/*

check timing for different data types
*/
#include <stdio.h>
#include <time.h>


int main()
{
    int dati[100000]={0};
    long long datd[100000]={0.};
    int i;
    clock_t tic, toc;

    tic = clock();
    for (i=0; i <100000; i++){
       dati[i] = i + 100;
       }
    toc = clock();

    printf("Elapsed time integer variables: %f seconds\n", (double)(toc - tic) / CLOCKS_PER_SEC);


    tic = clock();
    for (i=0; i <100000; i++){
       datd[i] = i + 100;
       }
    toc = clock();

    printf("Elapsed time double variables: %f seconds\n", (double)(toc - tic) / CLOCKS_PER_SEC);

    return 0;
}
