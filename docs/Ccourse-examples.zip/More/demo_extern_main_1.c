/* demo_extern_main_1.c 

connected to demo_extern_sub_1.c
compile gcc demo_extern_main_1.c   demo_extern_sub1.c
*/

#include <stdio.h>

int a=4;
int b=8;
int test( );

int main( )
{
	printf("a=%d,b=%d\n",a,b);
	a = b = 5;
	test();
	return 0;
}
