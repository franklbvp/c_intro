#include <stdio.h>

//enum_01.c

enum week_days  
{ 
    monday=88,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
    sunday
};
int main(void)  
{
    printf("Monday is the %dst day of the week.\n", monday);
    printf("Thursday is the %dth day of the week.\n", thursday);
    printf("Sunday is the %dth day of the week.\n", sunday);
    return (0);
}