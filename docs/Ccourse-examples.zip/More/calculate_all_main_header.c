#include <stdio.h>
#include "avg.h"
#include "largest.h"
/*
calculate_all_main.c
needs: avg.c  largest.c
perform some calculations on 2 integer numbers

*/

int main()
{
  int a = 10;
  int b = 20;
  int r1, r2; 
  r1 = avg( a, b );
  r2 = largest( a, b);
  printf( "average of %d and %d is %d\n", a, b, r1 );
  printf( "largest of %d and %d is %d\n", a, b, r2 );
  return  0;
}
