/* demo_extern_sub_1.c */

#include <stdio.h>

extern int a;
extern int b;

int test( )
{
	printf("a=%d,b=%d\n",a,b);
}
