#include <stdio.h>
#include <stdlib.h>

/*
passing_function_01.c

basic example passing a function as a parameter to a function

based on https://stackoverflow.com/questions/9410/how-do-you-pass-a-function-as-a-parameter-in-c
*/

void print ( int x ); 
void func ( void (*f)(int) ); // prototype for a function which takes a function parameter

int main(void){

int a = 9;

print(a); // call the print function

func(print); // call func with the function print as a parameter

return EXIT_SUCCESS;

}

void print ( int x ) {
  printf("%d\n", x);
}

void func ( void (*f)(int) ) {
  for ( int ctr = 0 ; ctr < 5 ; ctr++ ) {
    (*f)(ctr);
  }
}