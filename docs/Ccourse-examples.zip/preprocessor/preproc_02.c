#include <stdio.h>
// preproc_02.c
#define BUFSIZE     5
#define NELEMS(a)   (sizeof(a) / sizeof(a[0]))
#define MIN(x,y)    ((x)<(y) ? (x) : (y))
#define SQR(x)      ((x)*(x))

int main(void)
{
    int i;
    double array[BUFSIZE] = { 56.3, -981.3, 23 };
    double s = array[0];

    for(i=1; i<NELEMS(array); ++i)
        s = MIN(s, array[i]);

    printf("s = %f\t SQR(s+5) = %f\n", s, SQR(s+5));

    return 0;
}
