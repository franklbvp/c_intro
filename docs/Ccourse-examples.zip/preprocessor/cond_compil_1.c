/*
cond_compil_1.c
example conditional compiling

compile with gcc –DDEBUG
or define DEBUG
*/

#include<stdio.h>


// # define DEBUG

int main()
{
#ifdef DEBUG 
    printf("Some debug info part 1 here \n");
#endif

    printf("Hello World \n");

#ifdef DEBUG 
    printf("Some debug info part 2 here \n");
#else
    printf("DEBUG macro not defined\n"); 
#endif

return 0;
}

