#include <stdio.h>

#define WORD1 
/* you don't have to put an expression after the defined word */

int main() {
#ifdef WORD1
 printf("1: WORD1 is defined so this bit is compiled.\n");
#endif

#ifndef WORD2
 printf("2: WORD2 is not defined so this bit is compiled.\n");
#endif

#undef WORD1
#define WORD2

#ifdef WORD1
 printf("3: WORD1 is now undefined so this bit is not compiled.\n");
#endif

#ifndef WORD2
 printf("4: WORD2 is now defined so this bit is not compiled.\n");
#endif

 return 0;
}
