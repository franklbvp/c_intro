/*
compile with gcc –DNEW
or define NEW

*/
#include<stdio.h>

// #define NEW  

int main()
{
 printf("Hello World 1 \n");

 #ifndef NEW
    printf("This is the old part \n");
 #else
    printf("This is the new part \n");
 #endif

 printf("Hello World 2 \n");

return 0;
}
