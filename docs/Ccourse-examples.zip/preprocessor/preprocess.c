/* Example of a multi-line preprocessor macro. */
#include <stdio.h>

#define intConv         "d"
#define doubleConv      "f"

#define PrintDebug( Expr, Type )                            \
        printf( __FILE__ ", line %d, " #Expr " = %" Type##Conv "\n",  \
            __LINE__, ( Expr ) )

int main(void)
{
    int x = 23, y = 57;

    PrintDebug(5/7.0, double);
    PrintDebug(150/7, int);
    PrintDebug(x *= y, int);

    return 0;
}
