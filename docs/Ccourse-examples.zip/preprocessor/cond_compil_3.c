/* 

conditional compiling header guard

example from http://codingfox.com/12-18-usage-of-conditional-compilation/

compile with arith.h twice included and once with arith_ok.h twice included
*/

#include <stdio.h>

/*
#include "arith.h"
#include "arith.h"
*/


#include "arith_ok.h"
#include "arith_ok.h"


int main()
{
 printf("Sum %d \n",sum(20,10));
 printf("Subtraction %d \n",sub(20,10));
 return 0;
}
