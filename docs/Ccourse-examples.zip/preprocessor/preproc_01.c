/*
preproc_01.c
show define and undef
*/
#include<stdio.h>

#define NUMBER 15

int main(void){

printf("NUMBER has the value %d \n", NUMBER);

#undef NUMBER
#define NUMBER  33

printf("NUMBER has the value %d \n", NUMBER);

return 0;
}
