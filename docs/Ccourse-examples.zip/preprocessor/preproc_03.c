#include <stdio.h>

#define MAX(a,b) (a>b ? a : b) /* a "function" */
#define DIFF1  4-7
#define DIFF2 (4-7)
#define NUMBER 10  /* NUMBER is always 10 */

int main() {
  int a=4, b=7;

  printf("Out of %d and %d, %d is the bigger number.\n", 
          a, b, MAX(a,b));
  printf("DIFF1 =  4-7.  DIFF1 times 10 equals %d.\n", DIFF1*10);
  printf("DIFF2 = (4-7). DIFF2 times 10 equals %d.\n", DIFF2*10);

  printf("I live at number %d.\n", NUMBER);
  printf("I'm moving soon...");

#undef NUMBER  
/* now undefine NUMBER so that we can give it a different value */
#define NUMBER 7

  printf(" now I live at number %d.\n", NUMBER);

  return 0;
}
