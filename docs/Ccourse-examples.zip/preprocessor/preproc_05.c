/*
preproc_05.c
predefined macros 
taken from: https://www.tutorialspoint.com/cprogramming/c_preprocessors.htm
*/

#include <stdio.h>

int main(void) {

   printf("File :%s\n", __FILE__ );
   printf("Date :%s\n", __DATE__ );
   printf("Time :%s\n", __TIME__ );
   printf("Line :%d\n", __LINE__ );

return 0;
}
