#include <stdio.h>

#define SQR(x)      (x * x)
#define SQR1(x)     ((x)*(x))

int main(void)
{
    double s = 15.0;


    printf("s = %f\t SQR(s+5) = %f\t SQR1(s+5) = %f\n", s, SQR(s+5), SQR1(s+5));

    return 0;
}
