/*

preproc_07.c

*/

#include<stdio.h>

#define VALMAX 1007  // try 7, 107, 1007
  
#if VALMAX > 200
   #undef VALMAX
   #define VALMAX 200
#elif VALMAX < 50
   #undef VALMAX
   #define VALMAX 50
#else
   #undef VALMAX
   #define VALMAX 100
#endif
 
int main()
{
    printf("VALMAX = %d \n",VALMAX);  
}   