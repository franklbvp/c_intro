/* Three equivalent versions of strcpy */
#include <stdio.h>

void strcpy_v1 (char *s, char *t)
{
    int i=0;
    while ((s[i] = t[i]) != '\0')
        ++i;
}

void strcpy_v2 (char *s, char *t)
{
    while ((*s = *t) != '\0') {
        ++s;
        ++t;
    }
}

void strcpy_v3 (char *s, char *t)
{
    while (*s++ = *t++)
        ;
}


int main(void)
{
    char *t = "A short message\n";
    char s1[50], s2[50], s3[50];

    strcpy_v1(s1, t);
    strcpy_v2(s2, t);
    strcpy_v3(s3, t);

    printf("%s%s%s", s1, s2, s3);

    return 0;
}
