#include <stdio.h>

/*
based on http://gribblelab.org/cbootcamp/6_Complex_Data_Types.html
*/

int main ()
{
  int grades[5] = {11, 9, 14, 15, 13};
  int local_arr[5];

  int i;

// copy an array?
//  local_arr = grades;

  for (i=0; i<5; i++) {
    local_arr[i] = grades[i];
  }

  for (i=0; i<5; i++) {
    printf("local_arr[%d]=%d\n", i, local_arr[i]);
  }


  return 0;
}
