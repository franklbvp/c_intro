#include <stdio.h>
#include <stdlib.h>
/*
array_passing_const.c

based on https://azrael.digipen.edu/~mmead/www/Courses/CS170/Const-1.html#ARGUMENTS
*/
int find_largest2(const int a[], int size);

int
main ()
{
  int arr[10] = { 0, 1, 2, 3, 4, 4, 4, 1, 1, 1 };
  int n;
  int max_array;
  const int *parr;

  max_array = find_largest2(arr,10);
  printf("largest value in array = %d \n", max_array);
  return 0;
}


int find_largest2(const int a[], int size)
{
  int i;
  int max = a[0]; 
//  a[0] = 0;   /* ILLEGAL: elements are const, compiler prevents it */
  for (i = 1; i < size; i++)
  {
    if (a[i] > max) 
      max = a[i]; 
//    a[i] = 0; /* ILLEGAL: elements are const, compiler prevents it */
  }
  return max;
}