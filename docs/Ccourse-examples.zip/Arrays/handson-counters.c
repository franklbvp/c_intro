/*

hands-on: generate a distribution

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void) { 

int ratingCounters[11], i, response;
char entry;

for ( i = 0; i <= 10; ++i )
ratingCounters[i] = 0;


printf ("Enter your responses - stop entry with q \n");

while (1) {

scanf(" %c",&entry);
getchar(); // To consume the newline 

if (entry == 'q') break;

response = entry - '0';
if ( (response < 1) || (response >10) ) 
printf ("Bad response: %i\n", response);
else
++ratingCounters[response];
}


printf ("\n\nRating Number of Responses\n");
printf ("------ -------------------\n");
for ( i = 1; i <= 10; ++i )
printf ("%4i%14i\n", i, ratingCounters[i]);

return 0;
}