/*
https://www.tutorialspoint.com/cprogramming/c_passing_arrays_to_functions.htm

compile
gcc -o array_1 arrays_2function.c getAverage.c
*/

#include <stdio.h>
 
/* function declaration */
double getAverage(int arr[], int size);

int main () {

   /* an int array with 5 elements */
   int balance[5] = {1000, 2, 3, 17, 50};
   double avg;

   /* pass pointer to the array as an argument */
   avg = getAverage( balance, sizeof(balance)/sizeof(int) ) ;
 
   /* output the returned value */
   printf( "Average value is: %f \n", avg );
    
   return 0;
}
