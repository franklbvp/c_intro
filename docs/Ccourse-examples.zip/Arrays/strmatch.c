/*  
 Note, strstr() must be able to deal with following cases: 
    (1) sub is "", 
    (2) s is "",
    (3) sub ends mid s, (eg, sub = "is", s = "this is a test"),
    (4) sub ends end of s, (eg, sub = "test", s = "this is a test"),
    (5) sub not in s.
 These are "boundary conditions" of the function operation and are the most 
 likely areas where bugs might appear in the implementation. So, by testing
 these inputs, we ensure the correctness of the algorithm.

 We use an assert() to ensure function fails if it is passed a NULL pointer. */

char* strstr(const char* s, const char* sub)
/* Pattern matching: Find the substring sub in string s.
 * Return pointer to substring in s if found, else return NULL. */
{
    char *t, *r;
    assert(s != NULL && sub != NULL);

    while (1) {
        /* Search for match of first character */
        while (*sub != *s) { 
            if (*s == '\0') return NULL; /* no match */
            ++s;     
        }
        
        /* Attempt match for remaining substring. 
         * Note, we recheck *sub == *s to deal with the degenerate
         * case where sub is an empty string. */
        for (t = sub, r = s; *t == *r; ++t, ++r) 
            if (*t == '\0') return (char*)s; /* match, sub ends at end-of s */
        if (*t == '\0') return (char*)s;     /* match, but sub ends before end-of s */

        /* No match, keep searching */
        ++s;
    }
}
