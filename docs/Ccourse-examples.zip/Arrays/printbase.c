#include <stdio.h>
#include <assert.h>

#define BUF_SIZE    100
#define NELEMS(x)   (sizeof(x)/sizeof((x)[0]))

void print_base_b (unsigned x, unsigned b)
/* Convert decimal value x to a representation in base b. */
{
    char buf[BUF_SIZE];
    int q=x, i=0;

    /* Calculate digit for each place in base b */
    do { 
        x = q;
        q = x/b; 
        buf[i++] = "0123456789abcdefghijklmnopqrstuvwxyz"[x - q*b];
    } while (q>0);

    /* Print digits, in reverse order (most-significant place first) */
    for (--i; i>=0; --i)
        printf("%c", buf[i]);
    printf("\n");
}

int main(void)
{
    int i, base[] = {2, 8, 10, 16, 20, 26};

    for (i = 0; i < NELEMS(base); ++i) {
        printf("Base %2d: ", base[i]); 
        print_base_b(765, base[i]);
    }
}
