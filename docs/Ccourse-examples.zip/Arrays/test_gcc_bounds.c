#include <stdio.h>

// https://gcc.gnu.org/bugzilla/show_bug.cgi?id=35587

int main()
{
  int a[5];
  a[-1] = 0;                  // line 5: error
  a[+1] = 0;  // ok
  a[+5] = 0;                  // line 7: error
  a[16] = 0;                  // line 8: error
  printf("%d \n", a[16]);     // line 9: error
  int i=16;
  printf("%d \n", a[i]);      // line 11: error
  return 0;
}