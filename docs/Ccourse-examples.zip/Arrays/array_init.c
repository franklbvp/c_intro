#include <stdio.h>
/*
array_init.c
based on http://gribblelab.org/cbootcamp/6_Complex_Data_Types.html
*/

int main ()
{
  int grades[5] = {11, 9, 14, 15, 13};
//  int grades[5] = {11, 9, 14, 15, 13, 12};  // error?
  int grades2[5] = {[0]=1, [2]=3, [4]=5};
  int local_arr[10] = {-1};
  int days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

  int i;

// what are the initial values?
  for (i=0; i<5; i++) {
    printf("grades[%d]=%d\n", i, grades[i]);
  }

// what are the initial values?
  for (i=0; i<5; i++) {
    printf("grades2[%d]=%d\n", i, grades2[i]);
  }

// out of the boundary?
  printf("grades[5]=%d\n", grades[5]);
  printf("grades[100]=%d\n", grades[100]);


// what are the initial values?
  for (i=0; i<10; i++) {
    printf("local_arr[%d]=%d\n", i, local_arr[i]);
  }

// what are the initial values?
  for (i=0; i<12; i++) {
    printf("days[%d]=%d\n", i, days[i]);
  }
  return 0;
}
