#include <stdio.h>
#include <stdlib.h>
/*
array_passing_2.c
http://www.cs.yale.edu/homes/aspnes/classes/223/examples/pointers/sumArray.c
*/
void double_it (int[], int);	// prototype
int sumArray (int n, const int *a);

int
main ()
{
  int arr[10] = { 0 };
  int n;
  int sum_array;
  const int *parr;


// put values
  parr = arr;
  for (n = 0; n < 10; n++) {
    arr[n] = n;
    printf ("The content of cell %d is %d \n", n, arr[n]);
  }

// calculate the sum
  sum_array = sumArray (10, parr);

  printf ("\n\n");
  printf ("The sum of the array elements is %d \n", sum_array);

  return 0;
}


/* compute the sum of the first n elements of array a */
int
sumArray (int n, const int *a)
{
  int i;
  int sum;

  sum = 0;
  for (i = 0; i < n; i++) {
    sum += a[i];
  }

  return sum;
}
