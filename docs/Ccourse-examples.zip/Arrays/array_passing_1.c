#include <stdio.h>
#include <stdlib.h>
/*
array_passing_1.c
based on Computer programming in C for beginners 
*/
void double_it(int [], int); // prototype
int main()
{
int arr[10] = {0}, n;
for(n=0; n<10; n++)
   printf("The content of cell %d is initially %d \n", n, arr[n]);
double_it(arr, 10);
printf("\n\n");
for(n=0; n<10; n++)
   printf("The content of cell %d is now %d \n", n, arr[n]);
return 0;
}

void double_it(int a[], int i)
{
int k = 0;
a[0] = 1;
for(k=1; k<i; k++)
   a[k] = a[k-1] * 2;
}
