#include <stdio.h>
/*
array_pointer_2.c
based on Computer programming in C for beginners
*/

int main ()
{
  int grades[5]={10, 12, 11, 16, 7};
  int points[5];
  int * pa, * pb;
  int sg, spa;

   printf("The address contained in grades is %p \n", grades);
   printf("The address of grades[0] is %p \n", &grades[0]);
  
   pa = grades;
   printf("The address contained in pa is %p \n", pa);
  
// points = grades;  /* will this compile? */
  
   grades[4] = 6; /* Equivalent indexes. */
   printf("grades[4] updated %d \n", grades[4]);
   pa[4] = 7;
   printf("grades[4] updated %d \n", pa[4]);
   *(grades + 4) = 8;
   printf("grades[4] updated %d \n", *(grades+4));
   *(pa + 4) = 9;
   printf("grades[4] updated %d \n", *(pa+4));

   pb = &grades[1]; /* Equivalent addresses. */
   pb = &pa[1];
   pb = grades + 1;
   pb = pa + 1;

  
   sg = sizeof(grades);
   spa = sizeof(pa);
   printf("The size of grades is %d \n", sg);
   printf("The size of pa is %d \n", spa);
 
  return 0;
}

