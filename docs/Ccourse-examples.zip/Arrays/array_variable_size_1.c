#include <stdio.h>
#include <stdlib.h>

/*
taken from Samm Bott - C for Science
*/

void addMatrices (double **matrixA, double **matrixB,
		  double **matrixR, unsigned int rows, unsigned int cols);
void randomMatrix (double **matrix, unsigned int rows, unsigned int cols);
void printMatrix (double **matrix, unsigned int rows, unsigned int cols);
double **allocMatrix (unsigned int rows, unsigned int cols);
void freeMatrix (double **matrix);

int
main ()
{
  unsigned int rows, cols;
  double **matrixA, **matrixB, **matrixC;
  printf ("Enter rows cols: ");
  scanf ("%u %u", &rows, &cols);

  matrixA = allocMatrix (rows, cols);
  matrixB = allocMatrix (rows, cols);
  matrixC = allocMatrix (rows, cols);

  if (!matrixA || !matrixB || !matrixC)
    {				/* a little lazy, but it does the job */
      fprintf (stderr, "Unable to allocate matrices!\n");
      return -1;
    }

  randomMatrix (matrixA, rows, cols);
  randomMatrix (matrixB, rows, cols);
  addMatrices (matrixA, matrixB, matrixC, rows, cols);

  printf ("\n\nmatrix A = \n");
  printMatrix (matrixA, rows, cols);
  printf ("\n\nmatrixB = \n");
  printMatrix (matrixB, rows, cols);
  printf ("\n\nmatrixA + matrixB = \n");
  printMatrix (matrixC, rows, cols);

  freeMatrix (matrixC);
  freeMatrix (matrixB);
  freeMatrix (matrixA);
  return 0;
}



void
addMatrices (double **matrixA, double **matrixB,
	     double **matrixR, unsigned int rows, unsigned int cols)
{
  unsigned int i, j;
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      matrixR[i][j] = matrixA[i][j] + matrixB[i][j];
}

void
printMatrix (double **matrix, unsigned int rows, unsigned int cols)
{
  unsigned int i, j;

  for (i = 0; i < rows; i++)
    {
      for (j = 0; j < cols; j++)
	printf ("%8.5lf ", matrix[i][j]);
      printf ("\n");
    }
}


void
randomMatrix (double **matrix, unsigned int rows, unsigned int cols)
{
  unsigned int i, j;
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      matrix[i][j] = (double) rand () / RAND_MAX;
}


double **
allocMatrix (unsigned int rows, unsigned int cols)
{
  double **matrix;
  unsigned int i;

  matrix = (double **) malloc (rows * sizeof (double *));
  if (!matrix)
    return NULL;		/* failed */

  matrix[0] = (double *) malloc (rows * cols * sizeof (double));
  if (!matrix[0])
    {
      free (matrix);		/* we don’t need matrix any more */
      return NULL;		/* failed */
    }

  for (i = 1; i < rows; i++)
    matrix[i] = matrix[i - 1] + cols;

  return matrix;
}

void
freeMatrix (double **matrix)
{
  free (matrix[0]);
  free (matrix);
}
