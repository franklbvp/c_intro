#include <stdio.h>
/*
array_bounds.c
based on http://gribblelab.org/cbootcamp/6_Complex_Data_Types.html
*/

int main ()
{
  int grades[5];
  int i;

// what are the initial values?
  for (i=0; i<5; i++) {
    printf("grades[%d]=%d\n", i, grades[i]);
  }

// out of the boundary?
  printf("grades[5]=%d\n", grades[5]);
  printf("grades[10]=%d\n", grades[10]);

// assign a value
  for (i=0; i<5; i++) {
    grades[i]=i;
  }
  for (i=0; i<5; i++) {
    printf("grades[%d]=%d\n", i, grades[i]);
  }
  
  return 0;
}
