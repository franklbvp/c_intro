/*
https://www.tutorialspoint.com/cprogramming/c_passing_arrays_to_functions.htm
*/

double getAverage(int arr[], int size) {

   int i;
   double avg;
   double sum = 0;

   for (i = 0; i < size; ++i) {
      sum += arr[i];
   }

   avg = sum / size;

   return avg;
}
