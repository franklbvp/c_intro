
/* 
test boundaries 


*/
#include <stdio.h>


int main( void )  {
int anArray[10]= {0}; // Initialize the whole thing to 0.
int x, y , z;
x = 11;
y = 12;
z = 13;

anArray[ 13 ] = 7; // Compiler error!?
anArray[ x]= 0;// No compiler error, but runtime error!

return 0;
}