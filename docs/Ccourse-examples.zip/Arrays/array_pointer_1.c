#include <stdio.h>
/*
array_pointer_1.c
based on Computer programming in C for beginners
*/

int main ()
{
  int grades[5]={10, 12, 11, 16, 7};
  int * pa;

   printf("The address contained in grades is %p \n", grades);
   printf("The address of grades[0] is %p \n", &grades[0]);
  
  return 0;
}
