/* 

trying to figure out the connection between pointers and arrays

based on 
zippo1.c --  zippo info
http://www.9wy.net/onlinebook/CPrimerPlus5/ch10lev1sec7.html
 */

#include <stdio.h>

int main(void)

{

    int zippo1[8] = {12, 14, 16, 18, 11, 13, 15, 17};
    int zippo2[4][2] = { {2,4}, {6,8}, {1,3}, {5, 7} };
    int zippo3[2][3][2] = {{{31, 32}, {33, 34}, {35, 36}}, {{41, 42},{43, 44}, {45 , 46}}};

/* use the name of the array
remark the effect of +1, it stands for the whole subarray
1d: next cell
2d: next row
3d: next 2d-array
*/
    printf("   zippo1 = %p,    zippo1 + 1 = %p\n", zippo1, zippo1 + 1);
    printf("   zippo2 = %p,    zippo2 + 1 = %p\n", zippo2, zippo2 + 1);
    printf("   zippo3 = %p,    zippo3 + 1 = %p\n", zippo3, zippo3 + 1);
    printf(" \n");
    printf(" \n");

/*
going down 1 level
2d: row by row
3d: 2d array
*/
    printf("zippo2[0] = %p, zippo2[0] + 1 = %p\n", zippo2[0], zippo2[0] + 1);
    printf("  *zippo2 = %p,   *zippo2 + 1 = %p\n", *zippo2, *zippo2 + 1);

    printf("zippo3[0] = %p, zippo3[0] + 1 = %p\n", zippo3[0], zippo3[0] + 1);
    printf("  *zippo3 = %p,   *zippo3 + 1 = %p\n", *zippo3, *zippo3 + 1);

    printf(" \n");
    printf(" \n");

/*
getting the content
*/

    printf("zippo1[0] = %d\n", zippo1[0]);
    printf("zippo1[3] = %d\n", zippo1[3]);
    printf("*(zippo1+3) = %d\n", *(zippo1+3));
    printf(" \n");

    printf("zippo2[0][0] = %d\n", zippo2[0][0]);
    printf("  *zippo2[0] = %d\n", *zippo2[0]);
    printf("  *zippo2[2] = %d\n", *zippo2[2]);
    printf("    **zippo2 = %d\n", **zippo2);
    printf("      zippo2[2][1] = %d\n", zippo2[2][1]);
    printf("*(*(zippo2+2) + 1) = %d\n", *(*(zippo2+2) + 1));
    printf(" \n");

    printf("zippo3[0][0][0] = %d\n", zippo3[0][0][0]);
    printf("  *zippo3[0][0] = %d\n", *zippo3[0][0]);
    printf("  **zippo3[0] = %d\n", **zippo3[0]);
    printf("    ***zippo3 = %d\n", ***zippo3);

    printf("      zippo3[1][2][1] = %d\n", zippo3[1][2][1]);
    printf("      *(*(*(zippo3 +1)+2)+1) = %d\n", *(*(*(zippo3 +1)+2)+1));


    printf(" \n");



    return 0;

}

