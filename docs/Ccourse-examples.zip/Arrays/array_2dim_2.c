#include<stdio.h>
 int
main (void) 
{
  int i, j;
  double A[2][2];
   A[0][0] = 1.0;
  A[0][1] = 2.0;
  A[1][0] = 3.0;
  A[1][1] = 4.0;
   for (i = 0; i < 2; i++)
    
    {
       for (j = 0; j < 2; j++)
	printf ("%6.2lf ", A[i][j]);
       printf ("\n");
    }

return 0;}
