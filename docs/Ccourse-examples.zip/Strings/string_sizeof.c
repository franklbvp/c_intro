/*
http://gribblelab.org/cbootcamp/9_Strings.html
*/
#include <stdio.h>

int main(void) {

  char s[] = "paul";

  printf("s is %ld elements long\n", sizeof(s));

  return 0;
}
