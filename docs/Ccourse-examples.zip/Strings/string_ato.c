/*

based on https://www.tutorialspoint.com/c_standard_library/c_function_atof.htm
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main () {
   float val;
   int ival;
   char str[20];
   
   strcpy(str, "989934.89");
   val = atof(str);
   printf("String value = %s, Float value = %f\n", str, val);

   ival = atoi(str);
   printf("String value = %s, Integer value = %i\n", str, ival);

   strcpy(str, "tutorialspoint.com");
   val = atof(str);
   printf("String value = %s, Float value = %f\n", str, val);

   return(0);
}