/* 
taken from
Muhammad Faisal Amjad
 02/02/2014
String manipulation - Sorting of strings
COP 3223H - Spring 2014
*/

#include<stdio.h>
#include <string.h>
#define NAME_LENGTH 100

int main()
{
    int i,j;
    char str[10][NAME_LENGTH], temp[NAME_LENGTH];
    
    printf("Enter 10 words:\n");
    
    for(i=0;i<10;++i)
        gets(str[i]);
    
    for(i=0;i<9;++i)
       for(j=i+1;j<10 ;++j){
          if(strcmp(str[i],str[j])<0)
          {
            strcpy(temp,str[i]);
            strcpy(str[i],str[j]);
            strcpy(str[j],temp);
          }
    }
    
    printf("In lexicographical order: \n");
    
    for(i=0;i<10;++i){
       puts(str[i]);
    }
    
    return 0;
}
