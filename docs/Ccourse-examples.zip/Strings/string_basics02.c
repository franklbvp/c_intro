/* 
string_basics02.c

Character arrays and character pointers are often interchangeable, but there can be some very important differences. 
https://www.cs.uic.edu/~jbell/CourseNotes/C_Programming/CharacterStrings.html

*/  
  
#include <stdio.h>
#include <string.h>

int 
main () 
 { 
int i; 
char s6[7]="Hello"; //s6 is a fixed constant address, determined by the compiler
char * s7="Again";			//s7 is a pointer variable, that can be changed to point elsewhere

printf ("s6: %s \n", s6);
printf ("s7: %s \n", s7);
  
strcpy(s6, "never");	// assign a value - not initialized
s7 = "hello world";		//s7 allocates space for 10 ( typically ) - 6 for the characters plus another 4 for the pointer variable.
  
printf ("s6: %s \n", s6);
printf ("s7: %s \n", s7);

//strcpy(s6, "never never again");	// assign a value - not initialized
//printf ("s6: %s \n", s6);
  
s6[0] = 'j';  // will work
printf ("s6: %s \n", s6);

for (i = 0; i < 12; ++i)
  {
    printf("%c \n", *(s7+i));
  }
*(s7+3) = 'j';  // will not work

printf ("s7: %s \n", s7);
  
return 0;
}


