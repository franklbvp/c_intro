/* 

taken from Muhammad Faisal Amjad
String manipulation - placement of NULL character
COP 3223H - Spring 2014
*/

#include<stdio.h>
#include<string.h>

#define MAX_STRING_LEN 80

int main() 
{
  
  char Str1[MAX_STRING_LEN], Str2[MAX_STRING_LEN];
  int len, i;
  
  Str1[0] = 'o';
  Str1[1] = 'r';
  Str1[2] = 'a';
  Str1[3] = 'n';
  Str1[4] = 'g';
  Str1[5] = 'e';
  Str1[6] = '\0';
  
  Str2[0] = 'c';
  Str2[1] = 'o';
  Str2[2] = 'u';
  Str2[3] = 'n';
  Str2[4] = 't';
  Str2[5] = 'y';
  Str2[6] = ' ';
  Str2[7] = 'm';
  Str2[8] = 'a';
  Str2[9] = 'y';
  Str2[10] = 'o';
  Str2[11] = 'r';
  Str2[12] = '\0';
  
  printf("String1 :%s, length : %d\n",Str1, strlen(Str1));  
  printf("String2 :%s, length : %d\n",Str2, strlen(Str2));

  strcat(Str1, Str2);  //concatenate Str2 at the end of Str1
  
  printf("String1 :%s, length : %d\n",Str1, strlen(Str1));  
  printf("String2 :%s, length : %d\n",Str2, strlen(Str2));

  strcpy(Str1, Str2);  //copy Str2 in Str1
  
  printf("String1 :%s, length : %d\n",Str1, strlen(Str1));  
  printf("String2 :%s, length : %d\n",Str2, strlen(Str2));


  return 0;
}