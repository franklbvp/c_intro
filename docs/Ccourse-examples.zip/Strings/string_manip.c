#include <stdio.h>
#include <string.h>
int main (void)
{
  char string1[] = "this is";
char string2[] = "a  test";
char string3[20] = "Hello, ";  // a specific value is set to avoid stack smashing
char string4[] = "world!";
   printf ("string3 =  %s\n", string3);
  strcat (string3, string4);
  printf ("string3 =  %s\n", string3);
  if (strcmp (string1, string2) == 0) {
    printf ("strings are equal\n");}
  
  else {

	  printf ("strings are different\n");
  }
return 0;
}
