/* 
taken from
Muhammad Faisal Amjad
 02/02/2014
String manipulation 
COP 3223H - Spring 2014
*/
#include<stdio.h>
#include<string.h>

#define MAX_STRING_LEN 80

int main() 
{
  
  char Str[MAX_STRING_LEN];
  int len, i;
  
  Str[0] = 'o';
  Str[1] = 'r';
  Str[2] = 'a';
  Str[3] = 'n';
  Str[4] = 'g';
  Str[5] = 'e';
  Str[6] = '0';  //'0' is different from 0
  Str[7] = 0;

  len = strlen(Str);

  printf("Str:\t%s\n",Str);
  printf("length:\t%d\n\n",len);
  
  /* print characters in Str */
  
  printf("forward\n");
  for (i = 0; i < len; ++i) 
  {
    printf("Str[%d] = %c\n",i,Str[i]);
  }
  
  /* print characters in Str backwards */
  
  printf("\nbackward\n");
  for (i = len-1; i >= 0; --i) 
  {
    printf("Str[%d] = %c\n",i,Str[i]);
  }
    

  return 0;
}
