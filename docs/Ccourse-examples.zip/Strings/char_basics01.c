/* 

Special characters
*/

#include <stdio.h>
#include <string.h>

int main()
{

printf("I\'ve written \"Hello World\" too \t many times\n");

return 0;
}
