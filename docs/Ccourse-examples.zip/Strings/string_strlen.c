/*

source: https://www.programiz.com/c-programming/library-function/string.h/strlen
*/

#include <stdio.h>
#include <string.h>
int main()
{
    char a[20]="Program";
    char b[20]={'P','r','o','g','r','a','m','\0'};
    char c[20];

    printf("Enter string: \n");
    scanf( "%19s", c);

    printf("Length of string a = %ld \n",strlen(a));

    //calculates the length of string before null character.
    printf("Length of string b = %ld \n",strlen(b));
    printf("Length of string c = %ld \n",strlen(c));

    return 0;
}
