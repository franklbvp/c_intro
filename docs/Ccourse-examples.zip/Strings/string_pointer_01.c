/* 
string_pointer_01.c

*/  
  
#include <stdio.h>
#include <string.h>

int 
main () 
 { 
char * s7;			//s7 is a pointer variable, that can be changed to point elsewhere

printf ("s7: %s \n", s7);
  
strcpy(s7, "never");	// assign a value - not initialized

s7 = "hello";		//s7 points to another literal
  
printf ("s7: %s \n", s7);
  
s7 = "Pointer to a longer string";
  
printf ("s7: %s \n", s7);
  
return 0;

 
}



