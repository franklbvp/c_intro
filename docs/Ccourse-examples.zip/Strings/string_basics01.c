/* 
string_basics01.c
String manipulation - placement of NULL character
taken from COP 3223H 2014
*/

#include <stdio.h>
#include <string.h>

int main()
{
   char greeting[] = "Hello";
   char greeting2[6] = {'H', 'e', 'l', 'l', 'o', '\0'};

    
   printf("Greeting : %s\n\n", greeting);
      
   greeting[0] = 'H';
   greeting[1] = 'i';
   greeting[2] = '!';
   
   printf("Greeting : %s\n\n", greeting);
   printf("Greeting2 : %s\n\n", greeting2);
   
   greeting[3] = '\0';
   
   printf("Greeting : %s\n\n", greeting);
   
   greeting[0] = 'Y';
   greeting[1] = 'a';
   greeting[2] = 'h';
   greeting[3] = 'o';
   greeting[4] = 'o';
   greeting[5] = '!';
   
   printf("Greeting : %s\n\n", greeting);
   greeting[5] = 0;   //NULL character is implemented as integer 0.
   printf("Greeting : %s\n\n", greeting);

   return 0;
}
