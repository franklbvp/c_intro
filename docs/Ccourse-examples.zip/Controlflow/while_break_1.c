/* while_break_1.c  */

#include <stdio.h>

int main()
{
	int count_1 = 0;
	int count_2 = 0;
	int count_3 = 0;

	while (count_1 < 20) {
		count_2 = count_1 + 2;
		if (count_2 < 10) {
			count_3 = count_2 * 10;
			if (count_3 > 30)
				break;
			printf("count_1 = %d \n", count_1);
			printf("count_2 = %d \n", count_2);
			printf("count_3 = %d \n", count_3);
		}
		/*	statements after if */
		count_1 = count_1 + 1;
	}
	/* statements after loop */
	printf("final count_1 = %d \n", count_1);
	printf("final count_2 = %d \n", count_2);
	printf("final count_3 = %d \n", count_3);
	printf("finished \n");
}