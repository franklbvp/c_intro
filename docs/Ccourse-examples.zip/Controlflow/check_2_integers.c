#include <stdio.h>

int main(void) {

    int a, b;

    printf("Enter two integer numbers ");
    scanf("%d%d", &a,&b);

    if (a > b) {
    	printf("%d is greater than %d.\n", a, b);
    } 
    if (b > a) {
    	printf("%d is greater than %d.\n", b, a);
    } 
    if (a == b){
    	printf("Both are equal.\n");
    }

    return (0);
}
