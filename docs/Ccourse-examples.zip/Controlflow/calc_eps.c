#include <stdio.h>
#include <limits.h>

// check difference between double and float
// careful with the casting
// http://stackoverflow.com/questions/3478743/trying-to-write-a-code-for-finding-the-machine-epsilon

int main(void) {

    float epsi, epsmall;
//    double epsi, epsmall;

    epsi = 1.0;

    while ((1.0 + epsi) != 1.0) {

       epsmall = epsi;
       epsi = epsi / 2.0f;
//       epsi = epsi / 2.0;
    }


    printf("epsilon %g \n", epsmall);

 
    return (0);
}
