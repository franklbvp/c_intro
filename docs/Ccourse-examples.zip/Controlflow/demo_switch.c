/* demo_switch.c */

#include <stdio.h>
int main ()
{
  int c, i, nblanc, nrest, nnumber[10];
  nblanc = nrest = 0;
  for (i = 0; i < 10; i++)
    nnumber[i] = 0;
  while ((c = getchar ()) != EOF)
    {
      switch (c)
	{
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	  nnumber[c - '0']++;
	  break;
	case ' ':
	case '\n':
	case '\t':
	  nblanc++;
	  break;
	default:
	  nrest++;
	  break;
	}
    }
  printf ("numbers=");
  for (i = 0; i < 10; i++)
    printf (" %d", nnumber[i]);
  printf (", blancs = %d, rest = %d\n", nblanc, nrest);
}
