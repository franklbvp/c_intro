#include <stdio.h>

/*
calculate the cumulative sum

*/

int main(void) {

    int i, x;
    int csum;

    csum = 0;

    printf("Enter integer ");
    scanf("%d", &x);

    for (i=1; i <=x; i++) {
       csum = csum + i;
    }

    printf("cumulative sum: %d \n", csum);

    return(0);
}
