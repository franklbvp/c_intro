/* Fahrenheit to Celcius conversion table (K & R page 15) */
#include <stdio.h>


int main(void)
{
    int fahr;
    int Low = 0;
    int Up = 300;
    int Step = 20;

    for (fahr = Low; fahr <= Up; fahr += Step)
        printf("%3d \t%6.1f\n", fahr, (5.0/9.0) * (fahr-32.0));
}
