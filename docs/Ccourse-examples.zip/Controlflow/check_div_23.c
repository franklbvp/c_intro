#include <stdio.h>

int main(void) {

    int x;

    printf("Input integer number ");
    scanf("%d", &x);

// check divison by 2 and 3
    if (!(x % 2) && !(x % 3)) {
        printf("%d can be divided by 2 and 3\n", x);
    }
    if ((x % 2) || (x % 3)){
        printf("%d cannot be divided by 2 and 3\n", x);
    }
    return (0);
}
