
/*
cumsum-bruteforce-bis.c
cumulative sum of integers between 1 and 100
*/

#include <stdio.h>

int
main ()
{

  long int cumsum = 0;
  long int value = 1;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;

  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;
  cumsum = cumsum + value++;


  printf ("cumulative sum 1..100 = %ld \n", cumsum);

  return 0;
}
