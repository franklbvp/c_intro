/* 
GCD of two numbers using Euclid's algorithm
*/

#include <stdio.h>
#include <stdlib.h>

int main()

{
    int n1, n2 ;   // n1, n2 integer input
    int n, m ;                 // m largest number, n smallest number
    int r;         // r remainder

    printf("Enter two integers: ");
    scanf("%d %d", &n1, &n2);

    n1 = abs(n1);
    n2 = abs(n2);

    if (n1 > n2){
       n = n2;
       m = n1;
       }
    else{
       n = n1;
       m = n2;
       }


    while (n > 0)

    {
        r = m % n;
        m = n;
        n = r;
    }

    printf ("GCD = %d \n",m);

return 0;
}
