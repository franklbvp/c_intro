/*
cumsum-while.c
cumulative sum of integers between 1 and 100
*/

#include <stdio.h>

int main() {

long int cumsum = 0;
int i = 1;


while (i <= 100) {
   cumsum = cumsum + i;
   i = i + 1;
   }


printf("cumulative sum 1..100 = %ld \n", cumsum);

return 0;
}
