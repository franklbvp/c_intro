#include <stdio.h>

int main(void) {

    int x;

    printf("Input integer number ");
    scanf("%d", &x);

    if (x > 0){ 
        printf("It is positive number.\n");
    } 
    if (x < 0){
        printf("It is negative number.\n");
    } 
    if (x == 0){
        printf("It is 0.\n");
    }

    return (0);
}
