/*
cumsum-for.c
cumulative sum of integers between 1 and 100
*/

#include <stdio.h>

int main() {
   long int cumsum = 0;
   int i;
 

   for (i=1; i<=100; i++) {
           cumsum = cumsum + i;
        }


printf("cumulative sum 1..100 = %ld \n", cumsum);

return 0;

}
