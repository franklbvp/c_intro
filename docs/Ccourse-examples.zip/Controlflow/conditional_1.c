#include <stdio.h>

/* 
conditional_1.c
reads two ints–praises for following directions 
taken from https://www.cs.umd.edu/class/fall2015/cmsc106
*/

int main() {
int x, y;

x = 4;
y = 4;

printf("input x = %d, y = %d \n", x, y);

if ((x == y) && (x > 0)) {
   printf("Good Job\n");
   printf("We are done here\n");
}

if ((x == y) && (x < 0)){
   printf("Good Job\n");
   printf("We are not done here\n");
}

return 0;
}
