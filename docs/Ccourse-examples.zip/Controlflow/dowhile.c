#include <stdio.h>
/* 
dowhile.c
Demonstrate do-while loop */
int main (void)
{
    int val = 39802;
     printf("%d\n", val);

    /* Print integer in reverse order */
    do
    {
        printf("do-while-loop %d rest %d\n", val, val % 10);
        val /= 10;
    } while (val != 0);

    printf("\n");
}
