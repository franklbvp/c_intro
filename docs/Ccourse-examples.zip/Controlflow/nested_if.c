#include <stdio.h>
// nested_if.c 
int main () {

   /* local variable definition */
   int a;
   int b;
 
   printf("Enter an integer number (<= 100)");
   scanf("%d", &a);

   /* check the boolean condition */
   if( a == 100 ) {
   
      /* if condition is true then read another integer */

      printf("Enter another integer number (<= 200)");
      scanf("%d", &b);

      if( b == 200 ) {
         /* if condition is true then print the following */
         printf("Value of a is 100 and b is 200\n" );
      }
   }
   
   printf("Exact value of a is : %d\n", a );
   printf("Exact value of b is : %d\n", b );
 
   return 0;
}
