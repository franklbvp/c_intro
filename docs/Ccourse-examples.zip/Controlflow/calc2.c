#include <stdio.h>
// calc2.c
int main(void)
{
    double val1, val2, result;
    unsigned char op;
    int isok = 1;

    printf("Enter your expression.\n");
    scanf ("%lf %c %lf", &val1, &op, &val2);
 
    switch (op)                            
    {
        case '+':
            result = val1 + val2;
            break;

        case '-':
            result = val1 - val2;
            break;

        case '*':
            result = val1 * val2;
            break;

        case '/':
            if (val2 == 0) {
                printf("ERROR.  Divide by zero.\n");
                isok = 0;
            }
            else
                result = val1 / val2;
            break;

        default:
            printf("ERROR.  Invalid operator.\n"); 
            isok = 0;
            break;
    } 

    if (isok)
        printf("%f\n", result);

    return 0;
} 
