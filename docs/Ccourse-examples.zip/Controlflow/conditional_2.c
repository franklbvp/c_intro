/***********************************************************************
conditional_2.c
Author:		Ben Humphrey	digiben@gametutorials.com
Program:		Questions
Description:	Asks/Answers questions using if/else statements.
Date:			5/18/00
� 2000-2003 GameTutorials
***********************************************************************/
#include <stdio.h>

void main()
{
	int age=0;

	printf("How old are you? ");
	scanf("%d", &age);

	if(age > 20)
	{
		printf("You're over 20 huh?\n");
	}


	if(age > 30)
		printf("You're over 30!?\n");


	if(age < 20) {
		printf("You're a young'n!\n");
	}


	if(age < 20 && age > 12)
	{
		printf("Being in your teens can be tough...\n");
	}

	if(age == 100)
		printf("WOW!  What's your secret!?\n");
}
