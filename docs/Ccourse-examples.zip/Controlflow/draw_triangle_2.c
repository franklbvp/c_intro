#include <stdio.h>

/*
draw a triangle
*/

int main(void) {

    int i, j, width, level;


    level = 10;
    width = 2 * level + 1;

    printf("\n");
    
    
    for (i=1; i <level; i++) {
       
        for (j=1; j<=i; j++) {
           printf(" ");
        }
        for (j=1; j<level-i; j++) {
           printf("*");
        }
        printf("*");
        for (j=1; j<level-i; j++) {
           printf("*");
        }
        printf("\n");
    }

    return(0);
}
