/*
cumsum-bruteforce.c
cumulative sum of integers between 1 and 100
*/

#include <stdio.h>

int
main ()
{

  long int cumsum = 0;

  cumsum = cumsum + 1;
  cumsum = cumsum + 2;
  cumsum = cumsum + 3;
  cumsum = cumsum + 4;
  cumsum = cumsum + 5;
  cumsum = cumsum + 6;
  cumsum = cumsum + 7;
  cumsum = cumsum + 8;
  cumsum = cumsum + 9;
  cumsum = cumsum + 10;

  cumsum = cumsum + 11;
  cumsum = cumsum + 12;
  cumsum = cumsum + 13;
  cumsum = cumsum + 14;
  cumsum = cumsum + 15;
  cumsum = cumsum + 16;
  cumsum = cumsum + 17;
  cumsum = cumsum + 18;
  cumsum = cumsum + 19;
  cumsum = cumsum + 20;

  cumsum = cumsum + 21;
  cumsum = cumsum + 22;
  cumsum = cumsum + 23;
  cumsum = cumsum + 24;
  cumsum = cumsum + 25;
  cumsum = cumsum + 26;
  cumsum = cumsum + 27;
  cumsum = cumsum + 28;
  cumsum = cumsum + 29;
  cumsum = cumsum + 30;

  cumsum = cumsum + 31;
  cumsum = cumsum + 32;
  cumsum = cumsum + 33;
  cumsum = cumsum + 34;
  cumsum = cumsum + 35;
  cumsum = cumsum + 36;
  cumsum = cumsum + 37;
  cumsum = cumsum + 38;
  cumsum = cumsum + 39;
  cumsum = cumsum + 40;

  cumsum = cumsum + 41;
  cumsum = cumsum + 42;
  cumsum = cumsum + 43;
  cumsum = cumsum + 44;
  cumsum = cumsum + 45;
  cumsum = cumsum + 46;
  cumsum = cumsum + 47;
  cumsum = cumsum + 48;
  cumsum = cumsum + 49;
  cumsum = cumsum + 50;

  cumsum = cumsum + 51;
  cumsum = cumsum + 52;
  cumsum = cumsum + 53;
  cumsum = cumsum + 54;
  cumsum = cumsum + 55;
  cumsum = cumsum + 56;
  cumsum = cumsum + 57;
  cumsum = cumsum + 58;
  cumsum = cumsum + 59;
  cumsum = cumsum + 60;

  cumsum = cumsum + 61;
  cumsum = cumsum + 62;
  cumsum = cumsum + 63;
  cumsum = cumsum + 64;
  cumsum = cumsum + 65;
  cumsum = cumsum + 66;
  cumsum = cumsum + 67;
  cumsum = cumsum + 68;
  cumsum = cumsum + 69;
  cumsum = cumsum + 70;

  cumsum = cumsum + 71;
  cumsum = cumsum + 72;
  cumsum = cumsum + 73;
  cumsum = cumsum + 74;
  cumsum = cumsum + 75;
  cumsum = cumsum + 76;
  cumsum = cumsum + 77;
  cumsum = cumsum + 78;
  cumsum = cumsum + 79;
  cumsum = cumsum + 80;

  cumsum = cumsum + 81;
  cumsum = cumsum + 82;
  cumsum = cumsum + 83;
  cumsum = cumsum + 84;
  cumsum = cumsum + 85;
  cumsum = cumsum + 86;
  cumsum = cumsum + 87;
  cumsum = cumsum + 88;
  cumsum = cumsum + 89;
  cumsum = cumsum + 90;

  cumsum = cumsum + 91;
  cumsum = cumsum + 92;
  cumsum = cumsum + 93;
  cumsum = cumsum + 94;
  cumsum = cumsum + 95;
  cumsum = cumsum + 96;
  cumsum = cumsum + 97;
  cumsum = cumsum + 98;
  cumsum = cumsum + 99;
  cumsum = cumsum + 100;

  printf ("cumulative sum 1..100 = %ld \n", cumsum);

  return 0;
}
