#include <stdio.h>
#include <stdlib.h> // for rand() function
#include <time.h>   // time

/*
continue.c
Demonstrate "continue" operation
*/
int main(void)
{
	double r[50];
	int i;
	srand(time(0));

	/* Fill r with random numbers */
	for (i = 0; i < 50; ++i)
	{
		r[i] = rand() / (double)rand() - 0.5;
		printf("%3.4f\t", r[i]);
	}
	printf("\n\n");


	/* Process r */
	for (i = 0; i < 50; ++i)
	{
		/* Skip the negative elements */
		if (r[i] < 0)
			continue;
		/* Process +ve elements */
		printf("%3.4f\t", r[i]);
	}
	printf("\n\n");
}

