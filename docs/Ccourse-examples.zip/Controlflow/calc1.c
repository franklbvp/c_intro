/* 
calc_1.c

This program implements a *very* simple 4-function calculator that
evaluates expressions of the form:
        <number> <operator> <number>
The allowable operators are (+, -, *, /) 
*/
#include <stdio.h>

int main(void)
{
    double val1, val2, result;
    unsigned char op;
    int isok = 1;

    printf("Enter your expression.\n");
    scanf ("%lf %c %lf", &val1, &op, &val2);
 
    if (op == '+')
        result = val1 + val2;
    else if (op == '-')
        result = val1 - val2;
    else if (op == '*')
        result = val1 * val2;
    else if (op == '/') {
        if (val2 == 0) {
            printf("ERROR.  Divide by zero.\n");
            isok = 0;
        }
        else
            result = val1 / val2;
    }
    else {
        printf("ERROR.  Invalid operator.\n"); 
        isok = 0;
    } 

    if (isok)
        printf("%f\n", result);
    return 0;
} 
