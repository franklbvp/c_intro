/* demo_ifelse.c 
*/
#include <stdio.h>

void main()
{
	int number=0;

	printf("Enter number in between -20 and 20 ");

	scanf("%d", &number);
	
	if (number > 0)
	   printf("%d is a positive number \n", number);
	else {
	   printf("%d is a negative number \n", number);
	   printf(" positive numbers are better \n");    
    }
    printf("the end \n");

}