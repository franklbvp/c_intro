/* calculator */
/* based on Todd RPI */

#include<stdio.h>

int
main ()
{
  float oper1, oper2;
  int operator;
  float result;

  printf ("enter Number1: ");
  scanf ("%g", &oper1);
  printf ("enter Number2: ");
  scanf ("%g", &oper2);

  printf (" enter the operation (1: +, 2: -, 3: *)");
  scanf ("%d", &operator);

  switch (operator)
    {
    case 1:
      result = oper1 + oper2;
/*      break;
*/
/* carfeul with break */

    case 2:
      result = oper1 - oper2;
      break;

    case 3:
      result = oper1 * oper2;
      break;

    default:
      printf ("illegal operator \n");
      return (1);
      break;
    }
  printf (" result is %g \n", result);
}
