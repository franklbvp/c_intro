#include <stdio.h>
//infinite_while.c
int main()
{ 
  short int x = 0;  /* Don't forget to declare variables */
  
  while (1) { /* While true */
      printf( "%d\n", x );
      x++;             // Update x 
  }
}
