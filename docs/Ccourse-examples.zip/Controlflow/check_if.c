#include <stdio.h>

int main (void)
{
  int i;
  float f;
  char c;

  printf ("Enter an integer and a float, then Y or N\n> ");
  scanf ("%d %f %c", &i, &f, &c);
  printf ("You entered:\n");
  printf ("i = %d, f = %f, c = %c\n", i, f, c);

  if (i){
      printf(" i is considered true \n");}
  else {
      printf(" i is considered false  \n");}

  if (f)
      printf(" f is considered true  \n");
  else
      printf(" f is considered false  \n");

  if (c)
      {
      printf(" c is considered true \n");
      }
  else
      {
      printf(" c is considered false \n");
      }
  return 0;
}
