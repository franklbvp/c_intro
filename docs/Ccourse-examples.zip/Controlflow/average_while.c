#include <stdio.h>

int main(void) {

    int nstud, n;
    int smath, sphys, seng;
    int tmath, tphys, teng;
    float avgmath, avgphys, avgeng;

    tmath = 0;
    tphys = 0;
    teng = 0;

    printf("Enter number of students ");
    scanf("%d", &nstud);

    n = 1;

    while (n <= nstud) {
    
    printf("Enter score for student %d - math: ", n);
    scanf("%d", &smath);
    tmath = tmath + smath;

    printf("Enter score for student %d - physics: ", n);
    scanf("%d", &sphys);
    tphys = tphys + sphys;

    printf("Enter score for student %d - english: ", n);
    scanf("%d", &seng);
    teng = teng + seng;
    
    n = n + 1;
    }

// convert to float
// check what happens if the cast is not made
    avgmath = (float)tmath / (float)nstud;
    avgphys = (float)tphys / (float)nstud;
    avgeng = (float)teng / (float)nstud;

    printf("Average score math %g \n", avgmath);
    printf("Average score physics %g \n", avgphys);
    printf("Average score english %g \n", avgeng);

 
    return (0);
}
