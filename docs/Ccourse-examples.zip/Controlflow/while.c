#include <stdio.h>

/* Demonstrate while loop 
GCD “Brute Force”
*/ 
  int
main (void) 
{
  int n1, n2, n, i, gcd;
   printf ("Enter two integers: ");
  scanf ("%d %d", &n1, &n2);
   if (n1 > n2)
    n = n2;
  
  else
    n = n1;
   i = 1;
  gcd = 1;
   while (i <= n)
    {
      if (a % i == 0 && b % i == 0)
	gcd = i;
      i = i + 1;
       printf ("GCD = %d\n", gcd);
    }
  
