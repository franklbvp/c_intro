#include <stdio.h>
#include <ctype.h>

int main(void) {

    char x;

    printf("Enter class code ");
    scanf("%c", &x);

    x = toupper(x);

    switch(x){

    case 'A':
       printf("classroom 101 \n");
       break;

    case 'B':
       printf("classroom 201 \n");
       break;

    case 'C':
       printf("classroom 202 \n");
       break;

    default:
       printf("invalid class code \n");
    }


    return (0);
}
