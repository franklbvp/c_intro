/* high_low.c */
/* based on Todd RPI */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main()

{
   int number, choice;

   srand(time(NULL));
   number =  1 + rand() % 10;

   printf(" Choose number between 1 and 10: ");
   scanf(" %d", &choice);

   if (choice < number)
      printf(" too low! \n");
      else if (choice > number)
      printf(" too high! \n");
      else
      printf(" well done! \n");
      
   printf(" the correct number is %d \n", number);
}
