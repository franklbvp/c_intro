/* head_of_tail.c 
   based on Todd RPI 
   The C library function int rand(void) returns a 
   pseudo-random number in the range of 0 to RAND_MAX.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(void)

{
   int coin, choice;

/* Intializes random number generator */
/* The time() function returns information about the current 
   time of day, a value that’s constantly changing. The NULL
   argument helps solve some problems, but time() returns an 
   ever-changing value */

   srand(time(NULL));
   coin = rand() % 2;

   printf(" Make your choice (0: head - 1: tail):");
   scanf(" %d", &choice);

   if (choice == coin)
      {
      printf(" well done! \n");
      }
   return 0;
}
